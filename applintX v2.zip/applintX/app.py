import os
import threading
import webbrowser
from flask import Flask, render_template, request, jsonify

# Get the base directory (ensures correct paths even after converting to .exe)
BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Flask app with explicit static and template folders
app = Flask(__name__, 
            static_folder=os.path.join(BASE_DIR, "static"), 
            template_folder=os.path.join(BASE_DIR, "templates"))

# Automatically open the browser when the app starts
def open_browser():
    webbrowser.open_new("http://127.0.0.1:5000/")

# Home Route
@app.route("/")
def home():
    return render_template("PowerAppsAnalyser.html")

# Viewer Route
@app.route("/viewer")
def viewer():
    return render_template("sarifViewer.html")

# Error Details Route
@app.route("/errors")
def errors():
    return render_template("errorDetails.html")

# App Details Route
@app.route("/details")
def details():
    return render_template("appDetailsView.html")

# API Route to upload ZIP files
@app.route("/upload-zip", methods=["POST"])
def upload_zip():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No selected file"}), 400

    # Save the uploaded file (modify path if needed)
    upload_dir = os.path.join(BASE_DIR, "uploads")
    os.makedirs(upload_dir, exist_ok=True)  # Ensure directory exists
    upload_path = os.path.join(upload_dir, file.filename)
    file.save(upload_path)

    return jsonify({"message": "File uploaded successfully", "file": file.filename})

# API Route to fetch logged-in user
@app.route("/fetch-user", methods=["GET"])
def fetch_user():
    user_name = os.getenv("USER", "Guest")  # Get user name
    return jsonify({"userName": user_name})

# Run Flask App with automatic browser opening
if __name__ == "__main__":
    threading.Timer(1.25, open_browser).start()  # Open browser after 1.25 seconds
    app.run(host="127.0.0.1", port=5000)

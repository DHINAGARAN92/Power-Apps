window.viewMsappFiles = async function (uniqueName, documentUri) {
  if (!window.zipContent) {
    alert("⚠️ No ZIP file loaded. Please upload a ZIP file first.");
    console.error("❌ ZIP content is missing.");
    return;
  }

  try {
    console.log(`🔍 Extracting .msapp file for ${uniqueName} with Document URI: ${documentUri}`);

    const normalizedDocumentUri = documentUri.startsWith("/") ? documentUri.substring(1) : documentUri;
    const msappFile = Object.keys(window.zipContent.files).find((file) => file === normalizedDocumentUri);

    if (!msappFile) {
      alert(`⚠️ File ${normalizedDocumentUri} not found in the ZIP.`);
      console.error(`❌ File ${normalizedDocumentUri} not found in ZIP content.`);
      return;
    }

    const jszip = new JSZip();
    const msappBlob = await window.zipContent.files[msappFile].async("blob");
    const msappZipContent = await jszip.loadAsync(msappBlob);

    const sarifFile = Object.keys(msappZipContent.files).find((file) => file.endsWith("AppCheckerResult.sarif"));

    if (!sarifFile) {
      alert("⚠️ No AppCheckerResult.sarif file found in the .msapp package.");
      console.warn("❌ SARIF file not found in .msapp package.");
      return;
    }

    const sarifContent = await msappZipContent.files[sarifFile].async("string");

    // Store SARIF content and app name in localStorage
    localStorage.setItem("sarifContent", sarifContent);
    localStorage.setItem("appName", uniqueName);

    console.log("✅ SARIF content stored in localStorage.");

    // Open the SARIF Viewer page using Flask route
    window.open("/sarif-viewer", "_blank");
  } catch (error) {
    console.error("❌ Error processing .msapp file or SARIF file:", error);
    alert("❌ An error occurred while processing the .msapp file. Check the console for details.");
  }
};

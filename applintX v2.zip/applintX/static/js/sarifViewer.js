document.addEventListener("DOMContentLoaded", function () {
  const sarifContainer = document.getElementById("sarif-content");
  const categoryFilter = document.getElementById("primary-category-filter");
  const exportButton = document.getElementById("export-sarif-btn");

  if (!sarifContainer) {
    console.error("❌ SARIF content container not found.");
    return;
  }

  const sarifContent = localStorage.getItem("sarifContent");
  const appName = localStorage.getItem("appName") || "Unknown App";

  if (!sarifContent) {
    sarifContainer.innerHTML = `<p style="color: red;">⚠️ No SARIF data found.</p>`;
    return;
  }

  let sarifData;
  try {
    sarifData = JSON.parse(sarifContent);
  } catch (error) {
    console.error("❌ Error parsing SARIF data:", error);
    sarifContainer.innerHTML = `<p style="color: red;">⚠️ Error loading SARIF data. Please refresh and try again.</p>`;
    return;
  }

  // Extract results from SARIF
  const results = sarifData.runs?.[0]?.results || [];
  const rules = sarifData.runs?.[0]?.tool?.driver?.rules || [];

  // Map rules by their ID for easier access
  const ruleMap = {};
  rules.forEach((rule) => {
    ruleMap[rule.id] = rule;
  });

  let sarifHtml = `
    <div style="margin-bottom: 20px;">
      <h1 class="app-report-title">App Report for ${escapeHTML(appName)}</h1>
    </div>

    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
      <!-- Filter Dropdown -->
      <div>
        <label for="primary-category-filter" style="margin-right: 10px;">Filter by Primary Category:</label>
        <select id="primary-category-filter">
          <option value="">-- All Categories --</option>
          ${[...new Set(rules.map((rule) => escapeHTML(rule.properties?.primaryCategory || "N/A")))]
            .map((category) => `<option value="${category}">${category}</option>`)
            .join("")}
        </select>
      </div>

      <!-- Export Button -->
      <button id="export-sarif-btn" class="export-btn" style="margin-left: 10px;">Export to CSV</button>

      <!-- Close Button -->
      <span
        onclick="window.close()"
        style="cursor: pointer; font-size: 1.5rem; color: red; margin-left: 20px;"
        title="Close"
      >
        ✖
      </span>
    </div>

    <table id="sarif-table" class="styled-table">
      <thead>
        <tr>
          <th>Rule ID</th>
          <th>Message</th>
          <th>Location</th>
          <th>Severity</th>
          <th>How to Fix</th>
          <th>Why Fix</th>
          <th>Primary Category</th>
        </tr>
      </thead>
      <tbody>
        ${results
          .map((result) => {
            const ruleId = escapeHTML(result.ruleId || "N/A");
            const message = escapeHTML(result.message?.id || "N/A");
            const location = escapeHTML(result.locations?.[0]?.physicalLocation?.address?.fullyQualifiedName || "N/A");
            const severity = escapeHTML(result.properties?.level || "N/A");

            const rule = ruleMap[ruleId] || {};
            const howToFix = escapeHTML(rule.properties?.howToFix?.join("<br>") || "N/A");
            const whyFix = escapeHTML(rule.properties?.whyFix || "N/A");
            const primaryCategory = escapeHTML(rule.properties?.primaryCategory || "N/A");

            return `
              <tr data-category="${primaryCategory.toLowerCase()}">
                <td>${ruleId}</td>
                <td>${message}</td>
                <td>${location}</td>
                <td>${severity}</td>
                <td>${howToFix}</td>
                <td>${whyFix}</td>
                <td>${primaryCategory}</td>
              </tr>
            `;
          })
          .join("")}
      </tbody>
    </table>
  `;

  sarifContainer.innerHTML = sarifHtml;

  // Attach event listeners only if elements exist
  if (exportButton) {
    exportButton.onclick = () => {
      const dateTimeStamp = new Date().toISOString().replace(/[:.]/g, "-");
      const fileName = `${appName}_Report_${dateTimeStamp}.csv`;
      exportTableToCSV("sarif-table", fileName);
    };
  } else {
    console.warn("⚠️ Export button not found.");
  }

  if (categoryFilter) {
    categoryFilter.addEventListener("change", filterSarifTable);
  } else {
    console.warn("⚠️ Category filter dropdown not found.");
  }
});

// Filter SARIF Table by Primary Category
function filterSarifTable() {
  const filterValue = document.getElementById("primary-category-filter").value.toLowerCase();
  const rows = document.querySelectorAll("#sarif-table tbody tr");

  rows.forEach((row) => {
    const category = row.getAttribute("data-category")?.toLowerCase() || "";
    row.style.display = !filterValue || category === filterValue ? "" : "none";
  });
}

// Export Table to CSV
function exportTableToCSV(tableId, filename) {
  const table = document.getElementById(tableId);
  if (!table) {
    console.error(`❌ Table with ID '${tableId}' not found.`);
    return;
  }

  const rows = Array.from(table.rows);
  if (rows.length === 0) {
    console.warn("⚠️ No data available to export.");
    return;
  }

  const csvContent = rows
    .map((row) =>
      Array.from(row.cells)
        .map((cell) => `"${cell.textContent.replace(/"/g, '""')}"`) // Escape double quotes
        .join(",")
    )
    .join("\n");

  const blob = new Blob(["\uFEFF" + csvContent], { type: "text/csv;charset=utf-8;" });

  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Utility function to escape HTML (Prevents XSS attacks)
function escapeHTML(str) {
  if (!str) return "";
  return str.replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
}

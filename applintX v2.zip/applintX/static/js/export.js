// Export Table Data to CSV
window.exportTableToCSV = function (tableId, filename) {
  const table = document.getElementById(tableId);
  if (!table) {
    alert(`⚠️ Table with ID '${tableId}' not found.`);
    console.error(`❌ Table with ID '${tableId}' not found.`);
    return;
  }

  const rows = table.querySelectorAll("tr");
  if (rows.length === 0) {
    alert("⚠️ No data available to export.");
    console.error("❌ No table rows found for export.");
    return;
  }

  const csv = [];

  rows.forEach((row) => {
    const cols = row.querySelectorAll("th, td");
    const rowData = [];

    cols.forEach((col) => {
      let cellText = col.innerText.trim();
      // Escape quotes by doubling them (CSV format requirement)
      cellText = cellText.replace(/"/g, '""');

      // Wrap cell content in quotes to handle commas correctly
      rowData.push(`"${cellText}"`);
    });

    csv.push(rowData.join(","));
  });

  // Add UTF-8 BOM for correct encoding in Excel
  const csvContent = "\uFEFF" + csv.join("\n");
  const csvBlob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });

  // Create and trigger download link
  const downloadLink = document.createElement("a");
  downloadLink.href = URL.createObjectURL(csvBlob);
  downloadLink.download = filename;

  document.body.appendChild(downloadLink);
  downloadLink.click();
  document.body.removeChild(downloadLink); // Clean up
};

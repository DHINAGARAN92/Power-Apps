document.addEventListener("DOMContentLoaded", async function () {
  const categoryTitle = document.getElementById("error-category-title");
  const urlParams = new URLSearchParams(window.location.search);
  const category = urlParams.get("category") || "unknown";

  if (!categoryTitle) {
    console.error("❌ Error category title element not found.");
    return;
  }

  categoryTitle.textContent = `${category.charAt(0).toUpperCase() + category.slice(1)} Errors/Warnings`;

  const sarifContent = localStorage.getItem("consolidatedSarifData");

  if (!sarifContent) {
    console.warn("⚠️ No SARIF data found in localStorage.");
    document.getElementById("error-details-table").innerHTML = `<p>No SARIF data found. Please upload a ZIP file and try again.</p>`;
    return;
  }

  let allSarifData;
  try {
    allSarifData = JSON.parse(sarifContent);
  } catch (error) {
    console.error("❌ Error parsing SARIF data:", error);
    document.getElementById("error-details-table").innerHTML = `<p>Error loading SARIF data. Please refresh and try again.</p>`;
    return;
  }

  const filteredResults = [];

  // Aggregate results across all apps
  for (const { appName, sarifData, properties } of allSarifData) {
    if (!sarifData || !sarifData.runs || sarifData.runs.length === 0) {
      console.warn(`⚠️ No SARIF runs found for app: ${appName}. Skipping this app.`);
      continue;
    }

    const results = sarifData.runs[0].results || [];
    const rules = sarifData.runs[0].tool?.driver?.rules || [];

    console.log(`🔍 Processing app: ${appName}, Results Count: ${results.length}`);

    // Use the 'Name' from properties as the display name, fallback to appName if not available
    const displayName = properties?.Name || appName;
    console.log(`✅ Using Display Name for app: ${displayName}`);

    const filteredAppResults = results
      .map((result) => {
        const rule = rules.find((rule) => rule.id === result.ruleId);
        const primaryCategory = rule?.properties?.primaryCategory;

        if (!primaryCategory) {
          console.warn(
            `⚠️ No primaryCategory found for ruleId: ${result.ruleId} in app: ${displayName}. Skipping this result.`
          );
          return null;
        }

        if (primaryCategory.toLowerCase() !== category.toLowerCase()) return null;

        return {
          appName: escapeHTML(displayName),
          ruleId: escapeHTML(result.ruleId || "N/A"),
          message: escapeHTML(result.message?.id || "N/A"),
          location: escapeHTML(result.locations?.[0]?.physicalLocation?.address?.fullyQualifiedName || "N/A"),
          severity: escapeHTML(result.properties?.level || "N/A"),
          howToFix: escapeHTML(rule?.properties?.howToFix?.join("<br>") || "N/A"),
          whyFix: escapeHTML(rule?.properties?.whyFix || "N/A"),
        };
      })
      .filter(Boolean);

    filteredResults.push(...filteredAppResults);
  }

  if (filteredResults.length === 0) {
    console.log(`⚠️ No matching results found for category: ${category}`);
    document.getElementById("error-details-table").innerHTML = `<p>No matching results found for the selected category across all apps.</p>`;
    return;
  }

  // Generate table HTML
  const tableId = "error-details-table";
  const tableHTML = `
    <table id="${tableId}" class="styled-table">
      <thead>
        <tr>
          <th>App Name</th>
          <th>Rule ID</th>
          <th>Message</th>
          <th>Location</th>
          <th>Severity</th>
          <th>How to Fix</th>
          <th>Why Fix</th>
        </tr>
      </thead>
      <tbody>
        ${filteredResults
          .map((result) => `
            <tr>
              <td>${result.appName}</td>
              <td>${result.ruleId}</td>
              <td>${result.message}</td>
              <td>${result.location}</td>
              <td>${result.severity}</td>
              <td>${result.howToFix}</td>
              <td>${result.whyFix}</td>
            </tr>
          `)
          .join("")}
      </tbody>
    </table>
  `;

  document.getElementById("error-details-table").innerHTML = tableHTML;

  // Add Export Button (only once)
  const headerContainer = document.querySelector(".header-container");
  if (!headerContainer.querySelector(".export-btn")) {
    const exportButton = document.createElement("button");
    exportButton.className = "export-btn";
    exportButton.textContent = "Export to CSV";
    exportButton.onclick = () => exportTableToCSV(tableId, `${category}_errors_warnings.csv`);
    headerContainer.appendChild(exportButton);
  }
});

// Utility function to escape HTML (Prevents XSS attacks)
function escapeHTML(str) {
  if (!str) return "";
  return str.replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
}

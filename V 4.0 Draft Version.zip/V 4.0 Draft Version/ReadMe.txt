- UI to have Home page 
- Import solution 
- list all the Apps 
- Click on Details it should show App Check Details 
- Entity Details
- List Connection References
- Cloud Flows 

as on 01/9 4.45PM
document.addEventListener("DOMContentLoaded", function () {
  const sarifContent = localStorage.getItem("sarifContent");
  const appName = localStorage.getItem("appName");

  if (!sarifContent) {
    document.getElementById("sarif-content").innerHTML = `<p>No SARIF data found.</p>`;
    return;
  }

  const sarifData = JSON.parse(sarifContent);

  // Extract the results array from the SARIF data
  const results = sarifData.runs[0].results || [];
  const rules = sarifData.runs[0].tool.driver.rules || [];

  // Map rules by their ID for easier access
  const ruleMap = {};
  rules.forEach((rule) => {
    ruleMap[rule.id] = rule;
  });

  let sarifHtml = `
    <div style="margin-bottom: 20px;">
      <h1 style="text-align: center;">App Report for ${appName}</h1>
    </div>
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
      <!-- Filter Dropdown -->
      <div>
        <label for="primary-category-filter" style="margin-right: 10px;">Filter by Primary Category:</label>
        <select id="primary-category-filter" onchange="filterSarifTable()">
          <option value="">-- All Categories --</option>
          ${[...new Set(rules.map((rule) => rule.properties?.primaryCategory || "N/A"))]
            .map((category) => `<option value="${category}">${category}</option>`)
            .join("")}
        </select>
      </div>

      <!-- Export Button -->
      <button id="export-sarif-btn" style="margin-left: 10px;">Export to CSV</button>

      <!-- Close Button -->
      <span
        onclick="window.close()"
        style="cursor: pointer; font-size: 1.5rem; color: red; margin-left: 20px;"
        title="Close"
      >
        ✖
      </span>
    </div>

    <table id="sarif-table">
      <thead>
        <tr>
          <th>Rule ID</th>
          <th>Message</th>
          <th>Location</th>
          <th>Severity</th>
          <th>How to Fix</th>
          <th>Why Fix</th>
          <th>Primary Category</th>
        </tr>
      </thead>
      <tbody>
        ${results
          .map((result) => {
            const ruleId = result.ruleId || "N/A";
            const message = result.message?.id || "N/A";
            const location = result.locations[0]?.physicalLocation?.address?.fullyQualifiedName || "N/A";
            const severity = result.properties?.level || "N/A";

            const rule = ruleMap[ruleId] || {};
            const howToFix = rule.properties?.howToFix?.join("<br>") || "N/A";
            const whyFix = rule.properties?.whyFix || "N/A";
            const primaryCategory = rule.properties?.primaryCategory || "N/A";

            return `
              <tr data-category="${primaryCategory.toLowerCase()}">
                <td>${ruleId}</td>
                <td>${message}</td>
                <td>${location}</td>
                <td>${severity}</td>
                <td>${howToFix}</td>
                <td>${whyFix}</td>
                <td>${primaryCategory}</td>
              </tr>
            `;
          })
          .join("")}
      </tbody>
    </table>
  `;

  document.getElementById("sarif-content").innerHTML = sarifHtml;

  // Add Export Button Logic
  const exportBtn = document.getElementById("export-sarif-btn");
  exportBtn.onclick = () => exportTableToCSV("sarif-table", `${appName}_SarifReport.csv`);

  // Add Filter Logic
  document.getElementById("primary-category-filter").addEventListener("change", filterSarifTable);
});

// Filter SARIF Table by Primary Category
function filterSarifTable() {
  const filterValue = document.getElementById("primary-category-filter").value.toLowerCase();
  const rows = document.querySelectorAll("#sarif-table tbody tr");

  rows.forEach((row) => {
    const category = row.getAttribute("data-category").toLowerCase();
    if (!filterValue || category === filterValue) {
      row.style.display = "";
    } else {
      row.style.display = "none";
    }
  });
}

// Export Table to CSV
function exportTableToCSV(tableId, filename) {
  const table = document.getElementById(tableId);
  const rows = Array.from(table.rows);

  const csvContent = rows
    .map((row) => Array.from(row.cells).map((cell) => `"${cell.textContent}"`).join(","))
    .join("\n");

  const blob = new Blob([csvContent], { type: "text/csv" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

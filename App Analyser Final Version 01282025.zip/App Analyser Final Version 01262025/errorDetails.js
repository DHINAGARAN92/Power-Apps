document.addEventListener("DOMContentLoaded", async function () {
  const categoryTitle = document.getElementById("error-category-title");
  const urlParams = new URLSearchParams(window.location.search);
  const category = urlParams.get("category") || "unknown";

  categoryTitle.textContent = `${category.charAt(0).toUpperCase() + category.slice(1)} Errors/Warnings`;

  const sarifContent = localStorage.getItem("consolidatedSarifData");
  if (!sarifContent) {
    document.getElementById("error-details-table").innerHTML = `<p>No SARIF data found. Please upload a ZIP file and try again.</p>`;
    return;
  }

  const allSarifData = JSON.parse(sarifContent);
  const filteredResults = [];

  // Aggregate results across all apps
  for (const { appName, sarifData, properties } of allSarifData) {
    if (!sarifData || !sarifData.runs || sarifData.runs.length === 0) {
      console.warn(`No SARIF runs found for app: ${appName}. Skipping this app.`);
      continue;
    }

    const results = sarifData.runs[0].results || [];
    const rules = sarifData.runs[0].tool?.driver?.rules || [];

    console.log(`Processing app: ${appName}, Results Count: ${results.length}`);

    // Use the 'Name' from properties as the display name, fallback to appName if not available
    const displayName = properties?.Name || appName;
    console.log(`Using Display Name for app: ${displayName}`);

    const filteredAppResults = results
      .map((result) => {
        const rule = rules.find((rule) => rule.id === result.ruleId);
        const primaryCategory = rule?.properties?.primaryCategory;

        if (!primaryCategory) {
          console.warn(
            `No primaryCategory found for ruleId: ${result.ruleId} in app: ${displayName}. Skipping this result.`
          );
          return null;
        }

        if (primaryCategory.toLowerCase() !== category.toLowerCase()) return null;

        return {
          ...result,
          appName: displayName,
          howToFix: rule?.properties?.howToFix?.join("<br>") || "N/A",
          whyFix: rule?.properties?.whyFix || "N/A",
        };
      })
      .filter(Boolean);

    filteredResults.push(...filteredAppResults);
  }

  if (filteredResults.length === 0) {
    console.log(`No matching results found for category: ${category}`);
    document.getElementById("error-details-table").innerHTML = `<p>No matching results found for the selected category across all apps.</p>`;
    return;
  }

  // Generate table HTML
  const tableId = "error-details-table";
  const tableHTML = `
    <table id="${tableId}">
      <thead>
        <tr>
          <th>App Name</th>
          <th>Rule ID</th>
          <th>Message</th>
          <th>Location</th>
          <th>Severity</th>
          <th>How to Fix</th>
          <th>Why Fix</th>
        </tr>
      </thead>
      <tbody>
        ${filteredResults
          .map((result) => {
            const ruleId = result.ruleId || "N/A";
            const message = result.message?.id || "N/A";
            const location =
              result.locations?.[0]?.physicalLocation?.address?.fullyQualifiedName || "N/A";
            const severity = result.properties?.level || "N/A";
            const howToFix = result.howToFix;
            const whyFix = result.whyFix;

            return `
              <tr>
                <td>${result.appName}</td>
                <td>${ruleId}</td>
                <td>${message}</td>
                <td>${location}</td>
                <td>${severity}</td>
                <td>${howToFix}</td>
                <td>${whyFix}</td>
              </tr>
            `;
          })
          .join("")}
      </tbody>
    </table>
  `;

  document.getElementById("error-details-table").innerHTML = tableHTML;

  // Add Export Button (only once)
  const headerContainer = document.querySelector(".header-container");
  if (!headerContainer.querySelector(".export-btn")) {
    const exportButton = document.createElement("button");
    exportButton.className = "export-btn";
    exportButton.textContent = "Export to CSV";
    exportButton.onclick = () => exportTableToCSV(tableId, `${category}_errors_warnings.csv`);
    headerContainer.appendChild(exportButton);
  }
});

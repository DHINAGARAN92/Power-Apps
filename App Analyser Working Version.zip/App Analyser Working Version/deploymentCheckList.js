// Populate Deployment Checklist
window.populateDeploymentChecklist = function () {
  const checklistContent = document.getElementById("checklist-content");

  if (!checklistContent) {
    console.error("Deployment Checklist container not found!");
    return;
  }

  const checklistItems = [
    "Ensure all apps are updated to the latest version.",
    "Verify all connection references are valid.",
    "Check cloud flow triggers and dependencies.",
    "Validate environment variables.",
    "Run app checker to resolve any warnings or errors.",
    "Ensure all required users have appropriate security roles.",
    "Export the solution and test in a staging environment.",
  ];

  const checklistHtml = `
    <ul>
      ${checklistItems.map((item) => `<li>${item}</li>`).join("")}
    </ul>
  `;

  checklistContent.innerHTML = checklistHtml;
};

// Add Navigation for Deployment Checklist
document.getElementById("menu-deployment-checklist").addEventListener("click", () => {
  // Hide all other sections
  const sections = ["dashboard", "app-details", "entity-details", "connection-references", "cloud-flows"];
  sections.forEach((id) => (document.getElementById(id).style.display = "none"));

  // Show the Deployment Checklist section
  document.getElementById("deployment-checklist").style.display = "block";
   checklistSection.style.display = "block";

  // Populate the Deployment Checklist
  populateDeploymentChecklist();
});

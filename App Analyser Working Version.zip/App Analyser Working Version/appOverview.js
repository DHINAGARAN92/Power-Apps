// Populate App Overview Section with Additional Details
window.populateAppOverview = function (apps, connections, flows, zipFileName, sarifMetrics) {
  const appOverview = document.getElementById("canvas-app-overview");

  if (!appOverview) {
    console.error("App Overview container not found!");
    return;
  }

  // Extract version and type from the file name
  const fileName = zipFileName || "N/A";
  const versionMatch = fileName.match(/_(\d+_\d+_\d+_\d+)_/);
  const version = versionMatch ? versionMatch[1].replace(/_/g, ".") : "N/A";

  const typeMatch = fileName.match(/_(managed|unmanaged)\.zip$/i);
  const versionType = typeMatch ? typeMatch[1] : "N/A";

  const totalApps = apps.length;
  const canvasApps = apps.filter((app) => app.type === "Canvas").length;
  const modelDrivenApps = apps.filter((app) => app.type === "Model-Driven").length;

  const totalConnections = connections.length;
  const totalFlows = flows.length;

  const bestPractices = [
    "Ensure all apps are updated to the latest version.",
    "Verify all connection references are valid.",
    "Check cloud flow triggers and dependencies.",
    "Validate environment variables.",
    "Run app checker to resolve any warnings or errors.",
    "Ensure all required users have appropriate security roles.",
    "Export the solution and test in a staging environment.",
  ];

  const metricsHtml = Object.entries(sarifMetrics || {})
    .map(([category, count]) => `<li><strong>${category}:</strong> ${count} items</li>`)
    .join("");

  appOverview.innerHTML = `
    <div class="overview-container">
      <div class="overview-card">
        <h3><span style="margin-right: 8px;">📊</span>Total Apps</h3>
        <p><strong>${totalApps}</strong></p>
        <small>Canvas: ${canvasApps}, Model-Driven: ${modelDrivenApps}</small>
      </div>
      <div class="overview-card">
        <h3><span style="margin-right: 8px;">🔗</span>Connection References</h3>
        <p><strong>${totalConnections}</strong></p>
      </div>
      <div class="overview-card">
        <h3><span style="margin-right: 8px;">☁️</span>Cloud Flows</h3>
        <p><strong>${totalFlows}</strong></p>
      </div>
      <!-- Package Details Section -->
      <div class="overview-card" style="text-align: left;">
        <h3><span style="margin-right: 8px;">📦</span>Package Details</h3>
        <small><strong>Input File:</strong> ${fileName}</small><br>
        <small><strong>Version:</strong> ${version}</small><br>
        <small><strong>Type:</strong> ${versionType}</small>
      </div>
      <!-- Best Practices Section 
      <div class="overview-card" style="text-align: left;">
        <h3><span style="margin-right: 8px;">✔️</span>Best Practices</h3>
        <ul class="best-practices-list">
          ${bestPractices.map((item) => `<li>${item}</li>`).join("")}
        </ul>
      </div> -->
      <!-- SARIF Metrics Section -->
      <div class="overview-card">
        <h3><span style="margin-right: 8px;">📈</span>App Checker Metrics</h3>
        <ul>
          ${metricsHtml || "<li>No SARIF data found</li>"}
        </ul>
      </div>
    </div>
  `;
};
// Populate App Overview Section
window.populateAppOverview = function (apps, connections, flows) {
  const appOverview = document.getElementById("canvas-app-overview");

  if (!appOverview) {
    console.error("App Overview container not found!");
    return;
  }

  const totalApps = apps.length;
  const canvasApps = apps.filter((app) => app.type === "Canvas").length;
  const modelDrivenApps = apps.filter((app) => app.type === "Model-Driven").length;

  const totalConnections = connections.length;
  const totalFlows = flows.length;

  appOverview.innerHTML = `
    <!--<h2>App Overview</h2> -->
    <ul>
      <li><strong>Total Apps:</strong> ${totalApps} (Canvas: ${canvasApps}, Model-Driven: ${modelDrivenApps})</li>
      <li><strong>Total Connection References:</strong> ${totalConnections}</li>
      <li><strong>Total Cloud Flows:</strong> ${totalFlows}</li>
      <li><strong>Last Modified:</strong> ${new Date().toLocaleDateString()}</li>
    </ul>
  `;
};


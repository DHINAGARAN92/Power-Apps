- UI to have Home page 
- Import solution 
- list all the Apps 
- Click on Details it should show App Check Details 
- Entity Details
- List Connection References
- Cloud Flows 
- Added Filter Option to App Checker
- Removed Reference of cloud js unzip and added local file (libs) for extraction

as on 01/9 4.45PM
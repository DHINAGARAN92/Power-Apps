let entities = {};
let zipContent = null; // Store the ZIP content for SARIF extraction

document.addEventListener("DOMContentLoaded", function () {
  const importButton = document.getElementById("import-zip");
  const fileInput = document.getElementById("file-input");
  const fileNameDisplay = document.getElementById("file-name");
  const dashboard = document.getElementById("dashboard");
  const appDetails = document.getElementById("app-details");
  const entityDetails = document.getElementById("entity-details");
  const connReferences = document.getElementById("connection-references");
  const cloudFlows = document.getElementById("cloud-flows");

  // Handle import button click
  importButton.addEventListener("click", () => fileInput.click());

  // Handle file input change
  fileInput.addEventListener("change", async () => {
    const file = fileInput.files[0];
    if (file) {
      fileNameDisplay.textContent = `Selected File: ${file.name}`;
      await processZipFile(file);
    }
  });

  // Navigation: Home
  document.getElementById("menu-home").addEventListener("click", () => {
    dashboard.style.display = "block";
    appDetails.style.display = "none";
    entityDetails.style.display = "none";
    connReferences.style.display = "none";
    cloudFlows.style.display = "none";
	document.getElementById("app-details-section").style.display = "none"; 
  });

  // Navigation: App Details
  document.getElementById("menu-app-details").addEventListener("click", () => {
    dashboard.style.display = "none";
    appDetails.style.display = "block";
    entityDetails.style.display = "none";
    connReferences.style.display = "none";
    cloudFlows.style.display = "none";
	document.getElementById("app-details-section").style.display = "none"; 
  });

  // Navigation: Entity Details
  document.getElementById("menu-entities").addEventListener("click", () => {
    dashboard.style.display = "none";
    appDetails.style.display = "none";
    entityDetails.style.display = "block";
    connReferences.style.display = "none";
    cloudFlows.style.display = "none";
	document.getElementById("app-details-section").style.display = "none";
  });

  // Navigation: Connection References
  document.getElementById("menu-connection-references").addEventListener("click", () => {
    dashboard.style.display = "none";
    appDetails.style.display = "none";
    entityDetails.style.display = "none";
    connReferences.style.display = "block";
    cloudFlows.style.display = "none";
	document.getElementById("app-details-section").style.display = "none"; 
  });

  // Navigation: Cloud Flows
  document.getElementById("menu-cloud-flows").addEventListener("click", () => {
    dashboard.style.display = "none";
    appDetails.style.display = "none";
    entityDetails.style.display = "none";
    connReferences.style.display = "none";
    cloudFlows.style.display = "block";
	document.getElementById("app-details-section").style.display = "none"; 
  });
});

// import { populateAppOverview } from './appOverview.js';

// Process ZIP file
async function processZipFile(file) {
  try {
    const jszip = new JSZip();
    const zipContent = await jszip.loadAsync(file);
    window.zipContent = await jszip.loadAsync(file);
    const xmlContent = await zipContent.files["customizations.xml"].async("string");
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlContent, "text/xml");

    // Extract App details
const apps = Array.from(xmlDoc.querySelectorAll("CanvasApps > CanvasApp, AppModules > AppModule")).map((app) => {
  const displayName = app.tagName === "CanvasApp"
    ? app.querySelector("DisplayName")?.textContent?.trim() || "N/A" // For Canvas Apps
    : app.querySelector("LocalizedNames > LocalizedName")?.getAttribute("description")?.trim() || "N/A"; // For Model-Driven Apps

  const uniqueName = app.tagName === "CanvasApp"
    ? app.querySelector("Name")?.textContent?.trim() || "N/A" // For Canvas Apps
    : app.querySelector("UniqueName")?.textContent?.trim() || "N/A"; // For Model-Driven Apps

 const documentUri = app.tagName === "CanvasApp"
      ? app.querySelector("DocumentUri")?.textContent?.trim() || "N/A"
      : null; // Only Canvas Apps have DocumentUri
	  
  return {
    displayName: displayName,
    type: app.tagName === "CanvasApp" ? "Canvas" : "Model-Driven",
    uniqueName: uniqueName,
	documentUri, // Add DocumentUri to the app object
  };
});
    populateAppDetails(apps);

    // Extract Connection References
    const connections = Array.from(xmlDoc.querySelectorAll("connectionreferences > connectionreference")).map((conn) => ({
  displayName: conn.querySelector("connectionreferencedisplayname")?.textContent?.trim() || "N/A",
  logicalName: conn.getAttribute("connectionreferencelogicalname")?.trim() || "N/A", // Extract from attribute
  connectorId: conn.querySelector("connectorid")?.textContent?.trim() || "N/A",
}));
populateConnectionReferences(connections);


    // Extract Cloud Flows
    const flows = Array.from(xmlDoc.querySelectorAll("Workflows > Workflow")).map((flow) => ({
  name: flow.querySelector("LocalizedNames > LocalizedName")?.getAttribute("description")?.trim() || flow.getAttribute("Name") || "N/A", // Use LocalizedName if available, fallback to Name
  workflowId: flow.getAttribute("WorkflowId")?.trim() || "N/A", // Extract WorkflowId
}));
populateCloudFlows(flows);
// Debug Logs
    console.log("Apps Extracted:", apps);
    console.log("Connections Extracted:", connections);
    console.log("Flows Extracted:", flows);

 populateAppOverview(apps, connections, flows);
 
    // Extract entities and their attributes
    const entityNodes = xmlDoc.querySelectorAll("Entity");
    entities = {};
    entityNodes.forEach((entity) => {
      const entityName = entity.querySelector("Name[LocalizedName]")?.getAttribute("LocalizedName") || "N/A";
      const attributes = Array.from(entity.querySelectorAll("attributes > attribute")).map((attr) => ({
        name: attr.querySelector("Name")?.textContent || "N/A",
        type: attr.querySelector("Type")?.textContent || "N/A",
        required: attr.querySelector("RequiredLevel")?.textContent || "N/A",
        displayName: attr.querySelector("displayname")?.getAttribute("description") || "N/A",
        isCustom: attr.querySelector("IsCustomField")?.textContent === "1",
      }));
      entities[entityName] = attributes;
    });

    populateEntityDropdown();
  } catch (error) {
    console.error("Error processing ZIP file:", error);
  }
}

// Populate App Details Table with Magnifier Symbol
function populateAppDetails(apps) {
  const appTable = document.getElementById("app-details-table");
  let html = `
    <table id="app-details-table">
      <thead>
        <tr>
          <th>App Name</th>
          <th>App Type</th>
          <th>Logical Name</th>
          <th>Details</th>
        </tr>
      </thead>
      <tbody>
  `;
  apps.forEach((app) => {
    html += `
      <tr>
        <td>${app.displayName}</td>
        <td>${app.type}</td>
        <td>${app.uniqueName}</td>
        <td>
          <a href="#" onclick="event.preventDefault(); viewMsappFiles('${app.displayName}', '${app.documentUri}')">
            🔍
          </a>
        </td>
      </tr>
    `;
  });
  html += "</tbody></table>";
  appTable.innerHTML = html;

  // Add Export Button
  // addExportButton("app-details-table", "app-details", "AppDetails.csv");


  // Add event listeners for the "Details" links
  const detailLinks = document.querySelectorAll(".app-details-link");
  detailLinks.forEach((link) => {
    link.addEventListener("click", (event) => {
      event.preventDefault();
      const appIndex = event.target.getAttribute("data-index");
      openAppDetailsSection(apps[appIndex]);
    });
  });
}
// New Section for App Details
function openAppDetailsSection(app) {
  const detailsSection = document.getElementById("app-details-section");
  const detailsContainer = document.getElementById("app-details-content");

  // Populate the new section with app details
  const html = `
    <h2>App Details: ${app.displayName}</h2>
    <p><strong>App Type:</strong> ${app.type}</p>
    <p><strong>Unique Name:</strong> ${app.uniqueName}</p>
  `;

  detailsContainer.innerHTML = html;

  // Show the new section
  detailsSection.style.display = "block";

  // Hide other sections
  const otherSections = [dashboard, appDetails, entityDetails, connReferences, cloudFlows];
  otherSections.forEach((section) => section.style.display = "none");
}

// Function to process SARIF content
function processSarif(sarifContent) {
  const sarifData = JSON.parse(sarifContent);
  const results = sarifData.runs[0].results || [];
  return results.map(result => ({
    ruleId: result.ruleId || "N/A",
    message: result.message?.text || result.message?.id || "N/A",
    location: result.locations[0]?.logicalLocations[0]?.fullyQualifiedName || "N/A",
    severity: result.properties?.level || "N/A",
    fix: result.tool?.driver?.rules?.find(rule => rule.id === result.ruleId)?.properties?.howToFix || ["N/A"],
  }));
}


// Populate Connection References Table
function populateConnectionReferences(connections) {
  const connTable = document.getElementById("connection-references-table");
  let html = `
    <table>
      <thead>
        <tr>
          <th>Display Name</th>
          <th>Logical Name</th>
          <th>Connector ID</th>
        </tr>
      </thead>
      <tbody>
  `;
  connections.forEach((conn) => {
    html += `
      <tr>
        <td>${conn.displayName}</td>
        <td>${conn.logicalName}</td>
        <td>${conn.connectorId}</td>
      </tr>
    `;
  });
  html += "</tbody></table>";
  connTable.innerHTML = html;
}

// Populate Cloud Flows Table
function populateCloudFlows(flows) {
  const flowTable = document.getElementById("cloud-flows-table");
  let html = `
    <table>
      <thead>
        <tr>
          <th>Flow Name</th>
          <th>Workflow ID</th>
        </tr>
      </thead>
      <tbody>
  `;
  flows.forEach((flow) => {
    html += `
      <tr>
        <td>${flow.name}</td>
        <td>${flow.workflowId}</td>
      </tr>
    `;
  });
  html += "</tbody></table>";
  flowTable.innerHTML = html;
}

// Populate entity dropdown
function populateEntityDropdown() {
  const dropdownContainer = document.getElementById("dropdown-container");
  let dropdownHTML = '<select id="entitySelect" onchange="displayAttributes()">';
  dropdownHTML += '<option value="">--Select Entity--</option>';
  Object.keys(entities).forEach((entityName) => {
    dropdownHTML += `<option value="${entityName}">${entityName}</option>`;
  });
  dropdownContainer.innerHTML = dropdownHTML;
}

// Display entity attributes
function displayAttributes() {
  const selectedEntity = document.getElementById("entitySelect").value;
  const outputDiv = document.getElementById("output");

  if (!selectedEntity || !entities[selectedEntity]) {
    outputDiv.innerHTML = "";
    return;
  }

  const attributes = entities[selectedEntity];
  let html = `<h3>Attributes for ${selectedEntity}</h3>
              <table>
                <thead>
                  <tr>
                    <th>Display Name<br><input type="text" onkeyup="filterTable(0)" placeholder="Filter by display"></th>
                    <th>Attribute Name<br><input type="text" onkeyup="filterTable(1)" placeholder="Filter by name"></th>
                    <th>Type<br><input type="text" onkeyup="filterTable(2)" placeholder="Filter by type"></th>
                    <th>Required<br><input type="text" onkeyup="filterTable(3)" placeholder="Filter by required"></th>
                    <th>Column Type<br><input type="text" onkeyup="filterTable(4)" placeholder="Filter by type"></th>
                  </tr>
                </thead>
                <tbody>`;
  attributes.forEach((attr) => {
    html += `<tr>
                <td>${attr.displayName}</td>
                <td>${attr.name}</td>
                <td>${attr.type}</td>
                <td>${attr.required}</td>
                <td>${attr.isCustom ? "User-Created" : "Default"}</td>
             </tr>`;
  });

  html += "</tbody></table>";
  outputDiv.innerHTML = html;
}

// Filter table by column
function filterTable(columnIndex) {
  const input = event.target;
  const filter = input.value.toLowerCase();
  const table = document.querySelector("#output table");
  const rows = table.getElementsByTagName("tr");

  for (let i = 1; i < rows.length; i++) {
    const cell = rows[i].getElementsByTagName("td")[columnIndex];
    if (cell) {
      const textValue = cell.textContent || cell.innerText;
      rows[i].style.display = textValue.toLowerCase().includes(filter) ? "" : "none";
    }
  }
}


window.openAppDetails = async function (appName, documentUri) {
  if (!window.zipContent) {
    alert("No ZIP file loaded. Please upload a ZIP file first.");
    return;
  }

  try {
    console.log(`Extracting app details for ${appName} with Document URI: ${documentUri}`);

    // Normalize the Document URI
    const normalizedDocumentUri = documentUri.startsWith("/") ? documentUri.substring(1) : documentUri;

    // Locate the .msapp file in the CanvasApps folder
    const msappFile = Object.keys(window.zipContent.files).find(
      (file) => file.startsWith("CanvasApps/") && file.endsWith(normalizedDocumentUri)
    );

    if (!msappFile) {
      alert(`File ${normalizedDocumentUri} not found in the CanvasApps folder.`);
      console.warn("Available files in ZIP:", Object.keys(window.zipContent.files));
      return;
    }

    console.log("Found MSAPP file:", msappFile);

    const jszip = new JSZip();
    const msappBlob = await window.zipContent.files[msappFile].async("blob");
    const msappZipContent = await jszip.loadAsync(msappBlob);

    // Extract Properties.json
    const propertiesFile = msappZipContent.files["Properties.json"];
    if (!propertiesFile) {
      alert("Properties.json not found inside the MSAPP file.");
      return;
    }

    const propertiesContent = JSON.parse(await propertiesFile.async("string"));

    // Locate the AdditionalUris0_identity file
    const additionalUrisFileName = msappFile.replace("_DocumentUri.msapp", "_AdditionalUris0_identity.json");
    const additionalUrisFilePath = `CanvasApps/${additionalUrisFileName.replace("CanvasApps/", "")}`;

    console.log("Looking for AdditionalUris0_identity file:", additionalUrisFilePath);

    const additionalUrisFile = window.zipContent.files[additionalUrisFilePath];
    const components = additionalUrisFile
      ? Object.keys(JSON.parse(await additionalUrisFile.async("string")))
      : [];

    console.log("Extracted Components:", components);

    // Prepare app details
    const appDetails = {
      appName,
      documentUri,
      localDatabaseReferences: propertiesContent.LocalDatabaseReferences || [],
      maxGetRowsCount: propertiesContent.DefaultConnectedDataSourceMaxGetRowsCount || "N/A",
      components,
    };

    // Store app details in localStorage
    localStorage.setItem("appDetails", JSON.stringify(appDetails));

    // Navigate to appDetailsView.html
    window.open("appDetailsView.html", "_blank");
  } catch (error) {
    console.error("Error processing App Details:", error);
    alert("Failed to extract details for the selected app.");
  }
};

document.addEventListener("DOMContentLoaded", function () {
  // Fetch App Details from Local Storage
  const appDetails = localStorage.getItem("appDetails");

  // Ensure App Details Exist
  if (!appDetails) {
    console.error("No app details found in localStorage.");
    document.body.innerHTML = `
      <div style="text-align: center; margin-top: 20px;">
        <h2>Error: Unable to load app details</h2>
        <p>Please go back and select an app to view details.</p>
        <a href="index.html" style="text-decoration: none; color: blue;">Return to Home</a>
      </div>
    `;
    return;
  }

  const parsedAppDetails = JSON.parse(appDetails);
  console.log("App Details Loaded:", parsedAppDetails);

  const { appName, documentUri, localDatabaseReferences, maxGetRowsCount, components } = parsedAppDetails;

  // Categorize Components
  const categorizedComponents = {
    DataCard: [],
    Screen: [],
    Container: [],
    Button: [],
    Gallery: [],
    Others: [],
  };

  components.forEach((component) => {
    if (
      component.includes("DataCardKey") ||
      component.includes("DataCardValue") ||
      component.includes("DataCard") ||
      component.includes("ErrorMessage") ||
      component.includes("StarVisible")
    ) {
      categorizedComponents.DataCard.push(component);
    } else if (component.includes("Screen")) {
      categorizedComponents.Screen.push(component);
    } else if (component.includes("Container")) {
      categorizedComponents.Container.push(component);
    } else if (component.includes("Button")) {
      categorizedComponents.Button.push(component);
    } else if (component.includes("Gallery")) {
      categorizedComponents.Gallery.push(component);
    } else {
      categorizedComponents.Others.push(component);
    }
  });

  const componentsTable = `
    <h2>Components Categorized</h2>
    <table>
      <thead>
        <tr>
          <th>Category</th>
          <th>Components</th>
        </tr>
      </thead>
      <tbody>
        ${Object.entries(categorizedComponents)
          .map(
            ([category, items]) => `
            <tr>
              <td>${category}</td>
              <td>${items.length > 0 ? items.join("<br>") : "None"}</td>
            </tr>
          `
          )
          .join("")}
      </tbody>
    </table>
  `;

  let formattedDatabaseReferences = "None";
  let formattedDataSources = "None";

  if (localDatabaseReferences) {
    try {
      const parsedReferences = JSON.parse(localDatabaseReferences);

      formattedDatabaseReferences = Object.entries(parsedReferences)
        .map(([key, value]) => {
          const instanceUrl = value.instanceUrl || "N/A";
          const webApiVersion = value.webApiVersion || "N/A";
          const environmentVariableName = value.environmentVariableName || "N/A";

          if (value.dataSources) {
            formattedDataSources = Object.entries(value.dataSources)
              .map(([dsKey, dsValue]) => `${dsKey}: ${JSON.stringify(dsValue, null, 2)}`)
              .join("<br>");
          }

          return `
            <tr>
              <td>Instance URL</td>
              <td>${instanceUrl}</td>
            </tr>
            <tr>
              <td>Web API Version</td>
              <td>${webApiVersion}</td>
            </tr>
            <tr>
              <td>Environment Variable Name</td>
              <td>${environmentVariableName}</td>
            </tr>
          `;
        })
        .join("");
    } catch (error) {
      console.error("Error parsing Local Database References:", error);
      formattedDatabaseReferences = `
        <tr>
          <td>Local Database References</td>
          <td>Invalid JSON format</td>
        </tr>
      `;
    }
  }

  const appDetailsContent = `
    <h1>${appName} - App Details</h1>
    <table>
      <thead>
        <tr>
          <th>Property</th>
          <th>Value</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>App Name</td>
          <td>${appName}</td>
        </tr>
        <tr>
          <td>Document URI</td>
          <td>${documentUri}</td>
        </tr>
        <tr>
          <td>Max Get Rows Count</td>
          <td>${maxGetRowsCount}</td>
        </tr>
        ${formattedDatabaseReferences}
        <tr>
          <td>Data Sources</td>
          <td>${formattedDataSources}</td>
        </tr>
      </tbody>
    </table>
    ${componentsTable}
  `;

  const contentContainer = document.getElementById("app-details-content");
  if (!contentContainer) {
    console.error("Content container (#app-details-content) not found in the HTML.");
    return;
  }

  contentContainer.innerHTML = appDetailsContent;
});

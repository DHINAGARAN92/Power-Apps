// Export Table Data to CSV
window.exportTableToCSV = function (tableId, filename) {
  const table = document.getElementById(tableId);
  if (!table) {
    alert(`Table with ID ${tableId} not found.`);
    return;
  }

  const rows = table.querySelectorAll("tr");
  const csv = [];

  rows.forEach((row) => {
    const cols = row.querySelectorAll("th, td");
    const rowData = [];
    cols.forEach((col) => rowData.push(`"${col.innerText}"`));
    csv.push(rowData.join(","));
  });

  const csvBlob = new Blob([csv.join("\n")], { type: "text/csv" });
  const downloadLink = document.createElement("a");
  downloadLink.href = URL.createObjectURL(csvBlob);
  downloadLink.download = filename;
  downloadLink.click();
};

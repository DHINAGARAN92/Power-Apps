let entities = {};
let zipContent = null; // Store the ZIP content for SARIF extraction

document.addEventListener("DOMContentLoaded", function () {
  const importButton = document.getElementById("import-zip");
  const fileInput = document.getElementById("file-input");
  const fileNameDisplay = document.getElementById("file-name");
  const dashboard = document.getElementById("dashboard");
  const appDetails = document.getElementById("app-details");
  const entityDetails = document.getElementById("entity-details");
  const connReferences = document.getElementById("connection-references");
  const cloudFlows = document.getElementById("cloud-flows");
  const checklist = document.getElementById("deployment-checklist");
   const appOverviewHeading = document.getElementById("app-overview-heading");

  const menuItems = document.querySelectorAll(".nav-menu li");

  // Function to update active menu item
  function setActiveMenuItem(menuId) {
    menuItems.forEach((item) => {
      if (item.id === menuId) {
        item.classList.add("active");
      } else {
        item.classList.remove("active");
      }
    });
  }

  // Handle import button click
  importButton.addEventListener("click", () => fileInput.click());

  // Handle file input change
  fileInput.addEventListener("change", async () => {
    const file = fileInput.files[0];
    if (file) {
      fileNameDisplay.textContent = `Selected File: ${file.name}`;
      await processZipFile(file);
	        // Show the dashboard and App Overview heading after importing
      dashboard.style.display = "block";
      appOverviewHeading.style.display = "block";
    }
  });

  // Navigation: Home
  document.getElementById("menu-home").addEventListener("click", () => {
    setActiveMenuItem("menu-home");
    dashboard.style.display = "block";
    appDetails.style.display = "none";
    entityDetails.style.display = "none";
    connReferences.style.display = "none";
    cloudFlows.style.display = "none";
    checklist.style.display = "none";
    document.getElementById("app-details-section").style.display = "none"; 
  });

  // Navigation: App Details
  document.getElementById("menu-app-details").addEventListener("click", () => {
    setActiveMenuItem("menu-app-details");
    dashboard.style.display = "none";
    appDetails.style.display = "block";
    entityDetails.style.display = "none";
    connReferences.style.display = "none";
    cloudFlows.style.display = "none";
    checklist.style.display = "none";
    document.getElementById("app-details-section").style.display = "none"; 
  });

  // Navigation: Entity Details
  document.getElementById("menu-entities").addEventListener("click", () => {
    setActiveMenuItem("menu-entities");
    dashboard.style.display = "none";
    appDetails.style.display = "none";
    entityDetails.style.display = "block";
    connReferences.style.display = "none";
    cloudFlows.style.display = "none";
    checklist.style.display = "none";
    document.getElementById("app-details-section").style.display = "none";
  });

  // Navigation: Connection References
  document.getElementById("menu-connection-references").addEventListener("click", () => {
    setActiveMenuItem("menu-connection-references");
    dashboard.style.display = "none";
    appDetails.style.display = "none";
    entityDetails.style.display = "none";
    connReferences.style.display = "block";
    cloudFlows.style.display = "none";
    checklist.style.display = "none";
    document.getElementById("app-details-section").style.display = "none"; 
  });

  // Navigation: Cloud Flows
  document.getElementById("menu-cloud-flows").addEventListener("click", () => {
    setActiveMenuItem("menu-cloud-flows");
    dashboard.style.display = "none";
    appDetails.style.display = "none";
    entityDetails.style.display = "none";
    connReferences.style.display = "none";
    cloudFlows.style.display = "block";
    checklist.style.display = "none";
    document.getElementById("app-details-section").style.display = "none"; 
  });

  // Navigation: Deployment Checklist
  document.getElementById("menu-deployment-checklist").addEventListener("click", () => {
    setActiveMenuItem("menu-deployment-checklist");
    dashboard.style.display = "none";
    appDetails.style.display = "none";
    entityDetails.style.display = "none";
    connReferences.style.display = "none";
    cloudFlows.style.display = "none";
    checklist.style.display = "block";
    document.getElementById("app-details-section").style.display = "none"; 
  });
});


// import { populateAppOverview } from './appOverview.js';

// Process ZIP file
async function processZipFile(file) {
  try {
    const jszip = new JSZip();
    const zipContent = await jszip.loadAsync(file);
    window.zipContent = await jszip.loadAsync(file);
    const xmlContent = await zipContent.files["customizations.xml"].async("string");
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlContent, "text/xml");

    // Extract App details
  const apps = Array.from(xmlDoc.querySelectorAll("CanvasApps > CanvasApp, AppModules > AppModule")).map((app) => {
  const displayName = app.tagName === "CanvasApp"
    ? app.querySelector("DisplayName")?.textContent?.trim() || "N/A" // For Canvas Apps
    : app.querySelector("LocalizedNames > LocalizedName")?.getAttribute("description")?.trim() || "N/A"; // For Model-Driven Apps

  const uniqueName = app.tagName === "CanvasApp"
    ? app.querySelector("Name")?.textContent?.trim() || "N/A" // For Canvas Apps
    : app.querySelector("UniqueName")?.textContent?.trim() || "N/A"; // For Model-Driven Apps

 const documentUri = app.tagName === "CanvasApp"
      ? app.querySelector("DocumentUri")?.textContent?.trim() || "N/A"
      : null; // Only Canvas Apps have DocumentUri
	  
  return {
    displayName: displayName,
    type: app.tagName === "CanvasApp" ? "Canvas" : "Model-Driven",
    uniqueName: uniqueName,
	documentUri, // Add DocumentUri to the app object
  };
});
    populateAppDetails(apps);
	

    // Extract Connection References
    const connections = Array.from(xmlDoc.querySelectorAll("connectionreferences > connectionreference")).map((conn) => ({
  displayName: conn.querySelector("connectionreferencedisplayname")?.textContent?.trim() || "N/A",
  logicalName: conn.getAttribute("connectionreferencelogicalname")?.trim() || "N/A", // Extract from attribute
  connectorId: conn.querySelector("connectorid")?.textContent?.trim() || "N/A",
}));
populateConnectionReferences(connections);


// Extract Cloud Flows and Business Process Flows with Status and Primary Entity
const flows = Array.from(xmlDoc.querySelectorAll("Workflows > Workflow")).map((flow) => {
  const category = flow.querySelector("Category")?.textContent || "N/A";
  const stateCode = flow.querySelector("StateCode")?.textContent || "N/A";
  const primaryEntity = flow.querySelector("PrimaryEntity")?.textContent || "N/A";

  // Determine Flow Type based on Category
  let type = "Unknown"; // Default Type
  if (category === "2") type = "Business Process Flow";
  if (category === "5") type = "Cloud Flow";

  // Determine Status based on StateCode
  const status = stateCode === "0" ? "On" : stateCode === "1" ? "Off" : "Unknown";

  return {
    name: flow.querySelector("LocalizedNames > LocalizedName")?.getAttribute("description")?.trim() || flow.getAttribute("Name") || "N/A",
    type: type, // Flow Type
    workflowId: flow.getAttribute("WorkflowId")?.trim() || "N/A",
    status: status, // Status from StateCode
    primaryEntity: primaryEntity, // Entity Name
  };
});
populateCloudFlows(flows);


	
	const sarifMetrics = await extractSarifMetrics(zipContent);
    console.log("SARIF Metrics:", sarifMetrics);
	
 // Pass ZIP file name and details to app overview section along with extracted data
 populateAppOverview(apps, connections, flows ,file.name,sarifMetrics);
 
  // Automatically refresh the Home tab to show App Overview
    document.getElementById("menu-home").click(); // Simulate Home tab click
	
	// Call Dep Checklist File
	populateDeploymentChecklist();
 
    // Extract entities and their attributes
    const entityNodes = xmlDoc.querySelectorAll("Entity");
    entities = {};
    entityNodes.forEach((entity) => {
      const entityName = entity.querySelector("Name[LocalizedName]")?.getAttribute("LocalizedName") || "N/A";
      const attributes = Array.from(entity.querySelectorAll("attributes > attribute")).map((attr) => ({
        name: attr.querySelector("Name")?.textContent || "N/A",
        type: attr.querySelector("Type")?.textContent || "N/A",
        required: attr.querySelector("RequiredLevel")?.textContent || "N/A",
        displayName: attr.querySelector("displayname")?.getAttribute("description") || "N/A",
        isCustom: attr.querySelector("IsCustomField")?.textContent === "1",
      }));
      entities[entityName] = attributes;
    });

    populateEntityDropdown();
  } catch (error) {
    console.error("Error processing ZIP file:", error);
  }
}

// Populate App Details Table with Magnifier Symbol and App Details Link
function populateAppDetails(apps) {
  const appTable = document.getElementById("app-details-table");
  let html = `
    <table id="app-details-table">
      <thead>
        <tr>
          <th>App Name</th>
          <th>App Type</th>
          <th>Logical Name</th>
          <th>App Analyser</th>
        </tr>
      </thead>
      <tbody>
  `;
  apps.forEach((app) => {
    html += `
      <tr>
        <td>
          <a href="#" onclick="event.preventDefault(); openAppDetails('${app.displayName}', '${app.documentUri}')">
            ${app.displayName}
          </a>
        </td>
        <td>${app.type}</td>
        <td>${app.uniqueName}</td>
        <td>
          <a href="#" onclick="event.preventDefault(); viewMsappFiles('${app.displayName}', '${app.documentUri}')">
            🔍
          </a>
        </td>
      </tr>
    `;
  });
  html += "</tbody></table>";
  appTable.innerHTML = html;
}


// New Section for App Details
function openAppDetailsSection(app) {
  const detailsSection = document.getElementById("app-details-section");
  const detailsContainer = document.getElementById("app-details-content");

  // Populate the new section with app details
  const html = `
    <h2>App Details: ${app.displayName}</h2>
    <p><strong>App Type:</strong> ${app.type}</p>
    <p><strong>Unique Name:</strong> ${app.uniqueName}</p>
  `;

  detailsContainer.innerHTML = html;

  // Show the new section
  detailsSection.style.display = "block";

  // Hide other sections
  const otherSections = [dashboard, appDetails, entityDetails, connReferences, cloudFlows];
  otherSections.forEach((section) => section.style.display = "none");
}

// Function to process SARIF content
function processSarif(sarifContent) {
  const sarifData = JSON.parse(sarifContent);
  const results = sarifData.runs[0].results || [];
  return results.map(result => ({
    ruleId: result.ruleId || "N/A",
    message: result.message?.text || result.message?.id || "N/A",
    location: result.locations[0]?.logicalLocations[0]?.fullyQualifiedName || "N/A",
    severity: result.properties?.level || "N/A",
    fix: result.tool?.driver?.rules?.find(rule => rule.id === result.ruleId)?.properties?.howToFix || ["N/A"],
  }));
}


// Populate Connection References Table
function populateConnectionReferences(connections) {
  const connTable = document.getElementById("connection-references-table");
  let html = `
    <table>
      <thead>
        <tr>
          <th>Display Name</th>
          <th>Logical Name</th>
          <th>Connector ID</th>
        </tr>
      </thead>
      <tbody>
  `;
  connections.forEach((conn) => {
    html += `
      <tr>
        <td>${conn.displayName}</td>
        <td>${conn.logicalName}</td>
        <td>${conn.connectorId}</td>
      </tr>
    `;
  });
  html += "</tbody></table>";
  connTable.innerHTML = html;
}

// Populate Cloud Flows Table with Filters for Type and Status Columns
function populateCloudFlows(flows) {
  const flowTable = document.getElementById("cloud-flows-table");
  let html = `
    <table id="cloud-flows-table">
      <thead>
        <tr>
          <th>Flow Name</th>
          <th>
            Type<br>
            <select id="filter-type" onchange="filterCloudFlows()">
              <option value="">-- All Types --</option>
              <option value="Cloud Flow">Cloud Flow</option>
              <option value="Business Process Flow">Business Process Flow</option>
            </select>
          </th>
          <th>
            Status<br>
            <select id="filter-status" onchange="filterCloudFlows()">
              <option value="">-- All Statuses --</option>
              <option value="On">On</option>
              <option value="Off">Off</option>
            </select>
          </th>
          <th>Primary Entity</th>
        </tr>
      </thead>
      <tbody>
        ${flows
          .map(
            (flow) => `
          <tr data-type="${flow.type}" data-status="${flow.status}">
            <td>${flow.name}</td>
            <td>${flow.type}</td>
            <td>${flow.status}</td>
            <td>${flow.primaryEntity}</td>
          </tr>
        `
          )
          .join("")}
      </tbody>
    </table>
  `;
  flowTable.innerHTML = html;
}

// Filter Cloud Flows Table by Type and Status
function filterCloudFlows() {
  const typeFilter = document.getElementById("filter-type").value.toLowerCase();
  const statusFilter = document.getElementById("filter-status").value.toLowerCase();
  const rows = document.querySelectorAll("#cloud-flows-table tbody tr");

  rows.forEach((row) => {
    const rowType = row.getAttribute("data-type").toLowerCase();
    const rowStatus = row.getAttribute("data-status").toLowerCase();

    const matchesType = !typeFilter || rowType === typeFilter;
    const matchesStatus = !statusFilter || rowStatus === statusFilter;

    row.style.display = matchesType && matchesStatus ? "" : "none";
  });
}


// Populate entity dropdown
function populateEntityDropdown() {
  const dropdownContainer = document.getElementById("dropdown-container");
  let dropdownHTML = '<select id="entitySelect" onchange="displayAttributes()">';
  dropdownHTML += '<option value="">--Select Entity--</option>';
  Object.keys(entities).forEach((entityName) => {
    dropdownHTML += `<option value="${entityName}">${entityName}</option>`;
  });
  dropdownContainer.innerHTML = dropdownHTML;
}

// Display entity attributes
function displayAttributes() {
  const selectedEntity = document.getElementById("entitySelect").value;
  const outputDiv = document.getElementById("output");

  if (!selectedEntity || !entities[selectedEntity]) {
    outputDiv.innerHTML = "";
    return;
  }

  const attributes = entities[selectedEntity];
  let html = `<h3>Attributes for ${selectedEntity}</h3>
              <table>
                <thead>
                  <tr>
                    <th>Display Name<br><input type="text" onkeyup="filterTable(0)" placeholder="Filter by display"></th>
                    <th>Attribute Name<br><input type="text" onkeyup="filterTable(1)" placeholder="Filter by name"></th>
                    <th>Type<br><input type="text" onkeyup="filterTable(2)" placeholder="Filter by type"></th>
                    <th>Required<br><input type="text" onkeyup="filterTable(3)" placeholder="Filter by required"></th>
                    <th>Column Type<br><input type="text" onkeyup="filterTable(4)" placeholder="Filter by type"></th>
                  </tr>
                </thead>
                <tbody>`;
  attributes.forEach((attr) => {
    html += `<tr>
                <td>${attr.displayName}</td>
                <td>${attr.name}</td>
                <td>${attr.type}</td>
                <td>${attr.required}</td>
                <td>${attr.isCustom ? "User-Created" : "Default"}</td>
             </tr>`;
  });

  html += "</tbody></table>";
  outputDiv.innerHTML = html;
}

// Filter table by column
function filterTable(columnIndex) {
  const input = event.target;
  const filter = input.value.toLowerCase();
  const table = document.querySelector("#output table");
  const rows = table.getElementsByTagName("tr");

  for (let i = 1; i < rows.length; i++) {
    const cell = rows[i].getElementsByTagName("td")[columnIndex];
    if (cell) {
      const textValue = cell.textContent || cell.innerText;
      rows[i].style.display = textValue.toLowerCase().includes(filter) ? "" : "none";
    }
  }
}

// Add this function below your existing helper functions
async function extractSarifMetrics(zipContent) {
  const jszip = new JSZip();
  const msappFiles = Object.keys(zipContent.files).filter((file) =>
    file.startsWith("CanvasApps/") && file.endsWith(".msapp")
  );

  const categoryCounts = {};

  for (const msappFile of msappFiles) {
    try {
      const msappBlob = await zipContent.files[msappFile].async("blob");
      const msappZipContent = await jszip.loadAsync(msappBlob);

      const sarifFile = Object.keys(msappZipContent.files).find((file) =>
        file.endsWith("AppCheckerResult.sarif")
      );

      if (!sarifFile) continue;

      const sarifContent = await msappZipContent.files[sarifFile].async("string");
      const sarifData = JSON.parse(sarifContent);

      const rules = sarifData.runs[0].tool.driver.rules || [];
      rules.forEach((rule) => {
        const category = rule.properties?.primaryCategory || "Uncategorized";
        categoryCounts[category] = (categoryCounts[category] || 0) + 1;
      });
    } catch (error) {
      console.error(`Error processing SARIF for ${msappFile}:`, error);
    }
  }

  return categoryCounts;
}

document.addEventListener("DOMContentLoaded", () => {
  // Function to fetch the current logged-in user name
  async function fetchUserName() {
    try {
      // Simulate an API call or fetch from your backend system
      const userName = await Promise.resolve(""); // Example response
      return userName;
    } catch (error) {
      console.error("Failed to fetch user name:", error);
      return "Guest"; // Fallback to a default value
    }
  }

  // Function to update the time
  function updateTime() {
    const now = new Date();
    const formattedTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    document.getElementById("local-time").textContent = formattedTime;
  }

  updateTime();
  setInterval(updateTime, 1000);
});



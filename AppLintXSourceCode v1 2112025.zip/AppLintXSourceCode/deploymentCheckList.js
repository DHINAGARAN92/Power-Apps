// Populate Deployment Checklist
window.populateDeploymentChecklist = function (zipContent) {
  const checklistContent = document.getElementById("checklist-content");
  const componentCountsContent = document.getElementById("component-counts");

  if (!checklistContent || !componentCountsContent) {
    console.error("One or more containers (checklist-content or component-counts) not found!");
    return;
  }

  // Extract and populate components count
  async function extractAndDisplayEntityCounts(zipContent) {
    const jszip = new JSZip();
    try {
      const customizationsXML = await zipContent.files["customizations.xml"].async("string");
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(customizationsXML, "text/xml");

      // Extract component counts
      const apps = xmlDoc.querySelectorAll("CanvasApps > CanvasApp, AppModules > AppModule");
      const workflows = xmlDoc.querySelectorAll("Workflows > Workflow");
      const cloudFlows = Array.from(workflows).filter(
        (workflow) => workflow.querySelector("Category")?.textContent === "5"
      );
      const businessRules = Array.from(workflows).filter(
        (workflow) => workflow.querySelector("Category")?.textContent === "2"
      );
      const connectionReferences = xmlDoc.querySelectorAll("connectionreferences > connectionreference");
      const tables = xmlDoc.querySelectorAll("Entity");

      // Populate Components Count as a Table
      const countsHtml = `
        <h3>Components Count</h3>
        <table style="width: 100%; border-collapse: collapse;">
          <thead>
            <tr>
              <th style="border: 1px solid #ddd; padding: 8px;">Component</th>
              <th style="border: 1px solid #ddd; padding: 8px;">Count</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="border: 1px solid #ddd; padding: 8px;">Apps</td>
              <td style="border: 1px solid #ddd; padding: 8px;">${apps.length}</td>
            </tr>
            <tr>
              <td style="border: 1px solid #ddd; padding: 8px;">Cloud Flows</td>
              <td style="border: 1px solid #ddd; padding: 8px;">${cloudFlows.length}</td>
            </tr>
            <tr>
              <td style="border: 1px solid #ddd; padding: 8px;">Business Rules</td>
              <td style="border: 1px solid #ddd; padding: 8px;">${businessRules.length}</td>
            </tr>
            <tr>
              <td style="border: 1px solid #ddd; padding: 8px;">Connection References</td>
              <td style="border: 1px solid #ddd; padding: 8px;">${connectionReferences.length}</td>
            </tr>
            <tr>
              <td style="border: 1px solid #ddd; padding: 8px;">Tables</td>
              <td style="border: 1px solid #ddd; padding: 8px;">${tables.length}</td>
            </tr>
          </tbody>
        </table>
      `;
      componentCountsContent.innerHTML = countsHtml;
    } catch (error) {
      console.error("Error extracting components count:", error);
      componentCountsContent.innerHTML = `
        <div class="overview-card" style="color: red;">
          <h3>Components Count</h3>
          <p>Failed to extract components count. Ensure the ZIP file is valid.</p>
        </div>
      `;
    }
  }

  // Deployment checklist items
  const checklistItems = [
    "Ensure all apps are updated to the latest version.",
    "Verify all connection references are valid.",
    "Check cloud flow triggers and dependencies.",
    "Validate environment variables.",
    "Run app checker to resolve any warnings or errors.",
    "Ensure all required users have appropriate security roles.",
    "Export the solution and test in a staging environment.",
  ];

  // Populate Deployment Checklist
  const checklistHtml = `
    <h3>Good to have!</h3>
    <ul>
      ${checklistItems.map((item) => `<li>${item}</li>`).join("")}
    </ul>
  `;
  checklistContent.innerHTML = checklistHtml;

  // Trigger extraction for components count
  if (zipContent) {
    extractAndDisplayEntityCounts(zipContent);
  }
};

// Add Navigation for Deployment Checklist
document.addEventListener("DOMContentLoaded", function () {
  const deploymentMenu = document.getElementById("menu-deployment-checklist");
  if (!deploymentMenu) {
    console.error("Deployment checklist menu not found!");
    return;
  }

  deploymentMenu.addEventListener("click", () => {
    // Hide all other sections
    const sections = ["dashboard", "app-details", "entity-details", "connection-references", "cloud-flows"];
    sections.forEach((id) => {
      const section = document.getElementById(id);
      if (section) section.style.display = "none";
    });

    // Show the Deployment Checklist section
    const checklistSection = document.getElementById("deployment-checklist");
    if (checklistSection) {
      checklistSection.style.display = "block";
    }

    // Call populateDeploymentChecklist with the uploaded ZIP content
    if (window.zipContent) {
      populateDeploymentChecklist(window.zipContent);
    } else {
      console.warn("No ZIP file loaded. Cannot populate deployment checklist.");
    }
  });

  // Ensure Deployment Checklist loads data upon ZIP file upload
  const zipFileInput = document.getElementById("file-input");
  if (zipFileInput) {
    zipFileInput.addEventListener("change", async function (event) {
      const file = event.target.files[0];
      if (file) {
        const jszip = new JSZip();
        try {
          window.zipContent = await jszip.loadAsync(file);
          console.log("ZIP file loaded successfully for deployment checklist.");
        } catch (error) {
          console.error("Failed to process ZIP file:", error);
        }
      }
    });
  } else {
    console.error("ZIP file input element not found!");
  }
});


/******************************************************************************
* MakeAFP PDF2AFP API for Windows platform
*
* Copyright (C) 2017-2018, MakeAFP Inc. All rights reserved.
* Created: 2017.01.15
 *****************************************************************************/

#ifndef __MAKEAFP_PDF2AFP_WIN_H__
#define __MAKEAFP_PDF2AFP_WIN_H__

#ifndef _WIN32
  #error "This header file was only for Windows platform!"
#endif//_WIN32

#include <windows.h>
#include <tchar.h>

#define P2A_API
#define P2A_CALL     __stdcall
#define P2A_MAXPATH  512

#ifdef __cplusplus
extern "C" {
#endif//__cplusplus

// States of PDF2AFP Transform
typedef enum
{
	EP2AS_UNKNOWN,    // Unknown state
	EP2AS_READY,      // PDF2AFP Transform is ready
	EP2AS_RUNNING,    // PDF2AFP Transform is running
	EP2AS_ABORT,      // PDF2AFP Transform has encountered some serious problems, was forced to abort
	EP2AS_CANCELED,   // PDF2AFP Transform has been canceled by P2ACancelTransform
	EP2AS_COMPLETED,  // PDF2AFP Transform has completed the task
}EP2AState;

#pragma pack(push, 1)

// Get the transforming state and information
typedef struct
{
	EP2AState eState;             // Real-time state of the current PDF2AFP Transform
	WCHAR szSrcPDF[P2A_MAXPATH];  // Current source PDF filename
	WCHAR szDstAFP[P2A_MAXPATH];  // Current destination AFP filename
	BYTE  nProgress;              // Current transforming progress of the source PDF file, value range[0-100]
	BYTE  nTotalProgress;         // Total progress was used while transforming multiple PDF files
}TP2AStateInfo;

#pragma pack(pop)


// Initializes PDF2AFP Transform to read PDF from a file, and returns an PDF2AFP Transform handle.
// If the function fails, then return value is NULL
P2A_API HANDLE P2A_CALL P2AInitTransform(
	LPCWSTR pszCmdArgs,  // PDF2AFP command-line argument flags
	LPWSTR pszError      // Error messages, its buffer size recommended is above 1024
);


// Initializes PDF2AFP Transform to read PDF data stream from a memory buffer, and returns an PDF2AFP 
// Transform handle. If the function fails, then return value is NULL
P2A_API HANDLE P2A_CALL P2AInitTransStream(
	LPCWSTR pszCmdArgs,            // PDF2AFP command-line argument flags
	const char *pInPDFBuffer,      // Address of input PDF data stream buffer
	                               // *NOTE: While transforming, cannot release or free the memory buffer 
	int nPDFBufSize,               // Size of input PDF data stream
	const char **ppOutAFPBuffer,   // Pointer to the address of output AFP data stream buffer
	                               // *NOTE: Cannot release or free the pointer, released by P2ACloseTransform.
	int *pnOutAFPBufSize,          // Pointer to the size of output AFP data stream
	LPWSTR pszError                // Error messages, recommended buffer size is above 1024
);


// Start PDF2AFP transforming task
// Returns 0 - successful; 4 - warnings; 8 - errors; 12 - warnings and errors
P2A_API int P2A_CALL P2AStartTransform(
	HANDLE hTransform             // Handle returned by P2AInitTransform or P2AInitTransStream function
);


// Query the current running state of PDF2AFP Transform 
P2A_API BOOL P2A_CALL P2AQueryState(
	HANDLE hTransform,            // Handle returned by P2AInitTransform or P2AInitTransStream function
	TP2AStateInfo *pStateInfo     // PDF2AFP Transform state information
);


// Get the count of warning and error messages
P2A_API int P2A_CALL P2AGetErrorCount(HANDLE hTransform);


// Get the specified warning or error messages
P2A_API LPWSTR P2A_CALL P2AGetError(
	HANDLE hTransform,  // Handle returned by P2AInitTransform or P2AInitTransStream function
	int nErrorIndex,    // Index of errors, base 0
	LPWSTR pszBuffer,   // Address of buffer to retrieve the error messages
	DWORD dwSize        // Specifies the maximum buffer size, in WCHARs
);


// Cancel or stop current PDF2AFP transforming task
P2A_API void P2A_CALL P2ACancelTransform(
	HANDLE hTransform); // Handle returned by P2AInitTransform or P2AInitTransStream function


// Close and release current PDF2AFP Transform handle
P2A_API void P2A_CALL P2ACloseTransform(
	HANDLE hTransform); // Handle returned by P2AInitTransform or P2AInitTransStream function


#ifdef __cplusplus
}
#endif//__cplusplus&&extern "C"

#endif//__MAKEAFP_PDF2AFP_WIN_H__

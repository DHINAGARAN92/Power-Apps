
// 2015.06.07 by MakeAFP. 

#include "pdf2afp_win.h"
#include <stdio.h>


//////////////////////////////////////////////////////////////////////////
// Defines the API function pointers

typedef HANDLE (P2A_CALL * FnP2AInitTransform)(LPCWSTR pszCmdArgs, LPWSTR pszError);
typedef HANDLE (P2A_CALL * FnP2AInitTransStream)(LPCWSTR, const char *, int, const char **, int, LPWSTR);
typedef int    (P2A_CALL * FnP2AStartTransform)(HANDLE hTransform);
typedef BOOL   (P2A_CALL * FnP2AQueryState)(HANDLE hTransform, TP2AStateInfo *pStateInfo);
typedef int    (P2A_CALL * FnP2AGetErrorCount)(HANDLE hTransform);
typedef LPWSTR (P2A_CALL * FnP2AGetError)(HANDLE hTransform, int nErrorIndex, LPWSTR pszBuffer, DWORD dwSize);
typedef void   (P2A_CALL * FnP2ACancelTransform)(HANDLE hTransform);
typedef void   (P2A_CALL * FnP2ACloseTransform)(HANDLE hTransform);

static FnP2AInitTransform    s_pfnP2AInitTransform   = NULL;
static FnP2AInitTransStream  s_pfnP2AInitTransStream = NULL;
static FnP2AStartTransform   s_pfnP2AStartTransform  = NULL;
static FnP2AQueryState       s_pfnP2AQueryState      = NULL;
static FnP2AGetErrorCount    s_pfnP2AGetErrorCount   = NULL;
static FnP2AGetError         s_pfnP2AGetError        = NULL;
static FnP2ACancelTransform  s_pfnP2ACancelTransform = NULL;
static FnP2ACloseTransform   s_pfnP2ACloseTransform  = NULL;

// Initialize PDF2AFP API functions
static HMODULE s_hAPIModule = 0;
static BOOL _InitAPIFuncs()
{
	WCHAR szOldDir[MAX_PATH + 1] = { 0 };
	GetCurrentDirectoryW(MAX_PATH, szOldDir);

	// Modifies PDF2AFP install path according to your system
	SetCurrentDirectoryA("c:\\pdf2afp");
	s_hAPIModule = LoadLibraryExA("PDF2AFP.dll", NULL, 0);
	if (s_hAPIModule == NULL) {
		printf("Load PDF2AFP.dll failed, error code=0x%X", GetLastError());
		SetCurrentDirectoryW(szOldDir);
		return FALSE;
	}

	s_pfnP2AInitTransform   = (FnP2AInitTransform)GetProcAddress(s_hAPIModule, "P2AInitTransform");
	s_pfnP2AStartTransform  = (FnP2AStartTransform)GetProcAddress(s_hAPIModule, "P2AStartTransform");
	s_pfnP2AQueryState      = (FnP2AQueryState)GetProcAddress(s_hAPIModule, "P2AQueryState");
	s_pfnP2AGetErrorCount   = (FnP2AGetErrorCount)GetProcAddress(s_hAPIModule, "P2AGetErrorCount");
	s_pfnP2AGetError        = (FnP2AGetError)GetProcAddress(s_hAPIModule, "P2AGetError");
	s_pfnP2ACancelTransform = (FnP2ACancelTransform)GetProcAddress(s_hAPIModule, "P2ACancelTransform");
	s_pfnP2ACloseTransform  = (FnP2ACloseTransform)GetProcAddress(s_hAPIModule, "P2ACloseTransform");

	if ( s_pfnP2AInitTransform   == NULL
	  || s_pfnP2AStartTransform  == NULL
	  || s_pfnP2AQueryState      == NULL
	  || s_pfnP2AGetErrorCount   == NULL
	  || s_pfnP2AGetError        == NULL
	  || s_pfnP2ACancelTransform == NULL
	  || s_pfnP2ACloseTransform  == NULL ) {
		printf("Invalid PDF2AFP.dll\n");
		FreeLibrary(s_hAPIModule);
		s_hAPIModule = 0;
		SetCurrentDirectoryW(szOldDir);
		return FALSE;
	}
	SetCurrentDirectoryW(szOldDir);
	return TRUE;
}

static void _DestroyAPIFuncs()
{
	FreeLibrary(s_hAPIModule);
	s_hAPIModule = 0;
}


//////////////////////////////////////////////////////////////////////////
// Print PDF2AFP Transform warning and error messages

static void _PrintTransMessages(HANDLE hTransform)
{
	int i = 0;
	WCHAR szError[1024] = { 0 };
	int nMsgCount = (*s_pfnP2AGetErrorCount)(hTransform);
	for (i = 0; i < nMsgCount; ++ i) {
		(*s_pfnP2AGetError)(hTransform, i, szError, sizeof(szError));
		wprintf(L"* %d - %s\n", i+1, szError);
	}
}


//////////////////////////////////////////////////////////////////////////
// main entry

int wmain(int argc, WCHAR *argv[])
{
	int nReturnCode = 0;
	WCHAR szArgs[1024] = { 0 };
	WCHAR szError[1024] = { 0 };
	HANDLE hTransform = NULL;

	// Initialize PDF2AFP API functions
	if (!_InitAPIFuncs())
		return -1;

	// Initialize PDF2AFP Transform
	wsprintf(szArgs, L"c:\\pdf2afp\\test\\insure.pdf");
	hTransform = (*s_pfnP2AInitTransform)(szArgs, szError);
	if (hTransform == NULL) {
		wprintf(L"Initialize PDF2AFP Transform failed: %s\n", szError);
		_DestroyAPIFuncs();
		return -1;
	}

	// Start PDF2AFP Transform
	nReturnCode = (*s_pfnP2AStartTransform)(hTransform);
	if (nReturnCode >= 8) { // Ignore warning messages
		printf("PDF2AFP Transform failed:\n");
		_PrintTransMessages(hTransform);
		(*s_pfnP2ACloseTransform)(hTransform);
		_DestroyAPIFuncs();
		return -1;
	}
	printf("PDF2AFP Transform run successfully\n");

	// Release and close PDF2AFP Transform
	(*s_pfnP2ACloseTransform)(hTransform);
	_DestroyAPIFuncs();
	return 0;
}

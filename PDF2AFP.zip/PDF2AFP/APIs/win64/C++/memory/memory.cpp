
// 2015.06.09 by MakeAFP.

#include "pdf2afp_win.h"
#include <stdio.h>

// Ensure your system PATH environment include PDF2AFP Transform install path
#pragma comment (lib, "PDF2AFP.lib")


//////////////////////////////////////////////////////////////////////////
// Print PDF2AFP Transform warning and error messages

static void _PrintTransMessages(HANDLE hTransform)
{
	WCHAR szError[1024] = { 0 };
	int nMsgCount = P2AGetErrorCount(hTransform);
	for (int i = 0; i < nMsgCount; ++ i) {
		P2AGetError(hTransform, i, szError, sizeof(szError));
		wprintf(L"* %d - %s\n", i+1, szError);
	}
}


//////////////////////////////////////////////////////////////////////////
// main entry
// you can set PDF2AFP Transform install path to your PATH system variable
// such as in command line: set PATH=C:\PDF2AFP;%PATH%, then run memory.exe

int wmain(int argc, WCHAR * argv[])
{
	// In order to use data stream function, read PDF file to memory
	FILE *fp = fopen("c:\\pdf2afp\\test\\insure.pdf", "rb");
	if (fp == NULL) {
		printf("Open AFP file failed: error code=0x%X\n", GetLastError());
		return -1;
	}

	fseek(fp, 0, SEEK_END);
	int nInPDFSize = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	char *pInPDFBuf = (char *)malloc(nInPDFSize);
	if (pInPDFBuf == NULL) {
		printf("Out of memory\n");
		fclose(fp);
		return -1;
	}
	fread(pInPDFBuf, 1, nInPDFSize, fp);
	fclose(fp);

	// Initialize PDF2AFP Transform from memory buffer
	const char *pOutAFPBuf = NULL;
	int nOutAFPSize = 0;
	WCHAR szError[1024] = { 0 };
	HANDLE hTransform = P2AInitTransStream(NULL, pInPDFBuf, nInPDFSize, &pOutAFPBuf, &nOutAFPSize, szError);
	if (hTransform == NULL) {
		wprintf(L"Initialize PDF2AFP Transform failed: %s\n", szError);
		free(pInPDFBuf);
		return -1;
	}

	// Start PDF2AFP Transform
	int nReturnCode = P2AStartTransform(hTransform);
	if (nReturnCode >= 8) { // Ignore warning messages
		printf("PDF2AFP Transform failed:\n");
		_PrintTransMessages(hTransform);
		P2ACloseTransform(hTransform);
		free(pInPDFBuf);
		return -1;
	}
	printf("PDF2AFP Transform run successfully\n");
	free(pInPDFBuf);

	// Save output PDF memory buffer to local disk file
	fp = fopen("mem.afp", "wb");
	if (fp == NULL) {
		printf("Open mem.afp file failed, error code=0x%X\n", GetLastError());
		P2ACloseTransform(hTransform);
		return -1;
	}
	fwrite(pOutAFPBuf, 1, nOutAFPSize, fp);
	fclose(fp);

	// Release and close the converter
	P2ACloseTransform(hTransform);
	return 0;
}


// 2015.06.09 by MakeAFP.

#include "pdf2afp_win.h"
#include <stdio.h>

// Ensure your system PATH environment include PDF2AFP Transform install path
#pragma comment (lib, "PDF2AFP.lib")


//////////////////////////////////////////////////////////////////////////
// Print PDF2AFP Transform warning and error messages

static void _PrintTransMessages(HANDLE hTransform)
{
	int i = 0;
	WCHAR szError[1024] = { 0 };
	int nMsgCount = P2AGetErrorCount(hTransform);
	for (i = 0; i < nMsgCount; ++ i)
	{
		P2AGetError(hTransform, i, szError, sizeof(szError));
		wprintf(L"* %d - %s\n", i+1, szError);
	}
}


//////////////////////////////////////////////////////////////////////////
// main entry
// you can set PDF2AFP Transform install path to your PATH system variable
// such as in command line: set PATH=C:\PDF2AFP;%PATH%, then run static.exe

int wmain(int argc, WCHAR *argv[])
{
	int nReturnCode = 0;
	WCHAR szArgs[1024] = { 0 };
	WCHAR szError[1024] = { 0 };
	WCHAR szCurrDir[MAX_PATH+1] = { 0 };
	HANDLE hTransform = NULL;

	// Initialize PDF2AFP Transform
	wsprintf(szArgs, L"c:\\pdf2afp\\test\\insure.pdf");
	hTransform = P2AInitTransform(szArgs, szError);
	if (hTransform == NULL)
	{
		wprintf(L"Initialize PDF2AFP Transform failed: %s\n", szError);
		return -1;
	}

	// Start PDF2AFP Transform
	nReturnCode = P2AStartTransform(hTransform);
	if (nReturnCode >= 8)  // Ignore warning messages
	{
		printf("PDF2AFP Transform failed:\n");
		_PrintTransMessages(hTransform);
		P2ACloseTransform(hTransform);
		return -1;
	}
	printf("PDF2AFP Transform run successfully\n");

	// Release and close the converter
	P2ACloseTransform(hTransform);
	return 0;
}

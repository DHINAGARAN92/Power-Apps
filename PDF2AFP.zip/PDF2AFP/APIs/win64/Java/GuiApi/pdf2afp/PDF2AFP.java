
/******************************************************************************
* MakeAFP PDF2AFP Transform API for Java SDK
*
* Copyright (C) 2018, MakeAFP Inc. All rights reserved.
* Created: 2018.06.05
 *****************************************************************************/

package pdf2afp;

/**
 * MakeAFP PDF2AFP Transform API interface
 * 
 * @author MakeAFP.
 */
public class PDF2AFP {

    // States of PDF2AFP Transform
    public final static int EP2AS_UNKNOWN   = 0;  // Unknown state
    public final static int EP2AS_READY     = 1;  // PDF2AFP Transform is ready
    public final static int EP2AS_RUNNING   = 2;  // PDF2AFP Transform is running
    public final static int EP2AS_ABORT     = 3;  // PDF2AFP Transform has encountered some serious problems, was forced to abort
    public final static int EP2AS_CANCELED  = 4;  // PDF2AFP Transform has been canceled by P2ACancelTransform
    public final static int EP2AS_COMPLETED = 5;  // PDF2AFP Transform has completed the task
    
    /**
     * Initializes PDF2AFP Transform to read PDF from a file
     * 
     * @param sArgs PDF2AFP command-line argument flags
     * @param sError Error messages
     * @return returns a PDF2AFP Transform handle.
     *         If the function fails, then return value is 0
     */
    public static native long initTransform(String sArgs, StringBuffer sError);
    
    /**
     * Initializes PDF2AFP Transform to read AFP data stream from a memory buffer
     * @param sArg PDF2AFP command-line argument flags
     * @param pInAFPBuffer Input AFP data stream buffer
     * @param sError Error messages
     * @return returns an PDF2AFP Transform handle.
     *         If the function fails, then return value is 0
     */
    public static native long initTransStream(String sArg, byte[] pInAFPBuffer, StringBuffer sError);

    /**
     * Start PDF2AFP transforming task
     * @param hTransform Handle returned by P2AInitTransform or P2AInitTransStream function
     * @return 0 - successful; 4 - warnings; 8 - errors; 12 - warnings and errors
     */
    public static native int startTransform(long hTransform);
    
    /**
     * Get output PDF memory buffer
     * @param hTransform Handle returned by P2AInitTransStream function
     * @return PDF memory buffer
     */
    public static native byte[] getAFPStream(long hTransform);

    /**
     * Query the current running state of PDF2AFP Transform
     * @param hTransform Handle returned by P2AInitTransStream function
     * @param siState PDF2AFP Transform state information
     */
    public static native void queryState(long hTransform, P2AStateInfo siState);
    
    /**
     * Get the count of warning and error messages
     * @param hTransform Handle returned by P2AInitTransform or P2AInitTransStream function
     */
    
    /**
     * Get the count of warning and error messages
     * @param hTransform Handle returned by P2AInitTransform or P2AInitTransStream function
     * @return Count of warning and error messages
     */
    public static native int getErrorCount(long hTransform);
    
    /**
     * Get the specified warning or error messages
     * @param hTransform Handle returned by P2AInitTransform or P2AInitTransStream function
     * @param nErrorIndex Zero-based index of errors
     * @return warning or error message
     */
    public static native String getError(long hTransform, int nErrorIndex);
    
    /**
     * Cancel or stop current PDF2AFP transforming task
     * @param hTransform Handle returned by P2AInitTransform or P2AInitTransStream function
     */
    public static native void cancelTransform(long hTransform);
    
    /**
     * Close and release current PDF2AFP Transform handle
     * @param hTransform Handle returned by P2AInitTransform or P2AInitTransStream function
     */
    public static native void closeTransform(long hTransform);
    
    /**
     * The transforming state and information
     * 
     * @author MakeAFP.
    */
    public static class P2AStateInfo
    {
        public int State;           // Real-time state of the current PDF2AFP Transform
        public String SrcPDF;       // Current source PDF filename
        public String DstAFP;       // Current destination AFP filename
        public byte Progress;       // Current transforming progress of the source PDF file, value range[0-100]
        public byte TotalProgress;  // Total progress was used while transforming multiple PDF files
    }

    /**
     * Load JPDF2AFP library
     */
    static {
        try {
            System.loadLibrary("JPDF2AFP");
        } catch (UnsatisfiedLinkError e) {
            System.err.println("Could not load JPDF2AFP library:\n " + e.toString());
            System.exit(-1);
        }
    }
}

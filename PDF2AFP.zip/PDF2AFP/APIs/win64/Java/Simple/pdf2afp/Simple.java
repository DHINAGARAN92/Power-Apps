
/*
 * Copyright (c) 2015, MakeAFP. All rights reserved.
 * if JVM EXCEPTION_STACK_OVERFLOW, usage: java -Xss1m pdf2afp.Simple
 */
package pdf2afp; 

import pdf2afp.PDF2AFP;

public class Simple {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // Initialize PDF2AFP Transform
        StringBuffer sError = new StringBuffer();
       	long hTransform = PDF2AFP.initTransform("c:/pdf2afp/test/insure.pdf", sError);
        if (hTransform == 0) {
            System.out.println("Initialize PDF2AFP Transform failed: " + sError);
            return;
        }

        try {
            // Start PDF2AFP Transform
            int nReturnCode = PDF2AFP.startTransform(hTransform);

            // Ignore warning messages
            if (nReturnCode >= 8) {
                System.out.println("PDF2AFP Transform failed:");
                printTransMessages(hTransform);
                return;
            }
            System.out.println("PDF2AFP Transform run successfully");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Release and close the converter
            PDF2AFP.closeTransform(hTransform);
        }
    }

    protected static void printTransMessages(long hTransform) {
        int nMsgCount = PDF2AFP.getErrorCount(hTransform);
        for (int i = 0; i < nMsgCount; ++i) {
            String sError = PDF2AFP.getError(hTransform, i);
            System.out.printf("* %d - %s\n", i + 1, sError);
        }
    }
}

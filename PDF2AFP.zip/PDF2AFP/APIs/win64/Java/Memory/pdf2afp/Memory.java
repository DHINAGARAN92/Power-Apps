
/*
 * Copyright (c) 2015, MakeAFP. All rights reserved.
 * if JVM EXCEPTION_STACK_OVERFLOW, usage: java -Xss1m pdf2afp.Memory
 */
package pdf2afp;

import pdf2afp.PDF2AFP;

public class Memory {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        // In order to use data stream function, read AFP file to memory
        byte[] pInPDFBuf = null;
        java.io.InputStream inPDF = null;
        try {
            inPDF = new java.io.FileInputStream("c:/pdf2afp/test/insure.pdf");
            int nBytes = inPDF.available();
            if (nBytes <= 0) {
                System.out.println("empty input PDF file");
                return;
            }
            pInPDFBuf = new byte[nBytes];
            inPDF.read(pInPDFBuf, 0, nBytes);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (inPDF != null) {
                    inPDF.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (pInPDFBuf == null) {
            return;
        }

        // Initialize PDF2AFP Transform from memory buffer
        StringBuffer sError = new StringBuffer();
        String sArgs = "";  // Command-line arguments
        long hTransform = PDF2AFP.initTransStream(sArgs, pInPDFBuf, sError);
        if (hTransform == 0) {
            System.out.println("Initialize PDF2AFP Transform failed: " + sError);
            return;
        }
        pInPDFBuf = null;

        java.io.OutputStream outAFP = null;
        try {
            // Start PDF2AFP Transform
            int nReturnCode = PDF2AFP.startTransform(hTransform);

            // Ignore warning messages
            if (nReturnCode >= 8) {
                System.out.println("PDF2AFP Transform failed:");
                printTransMessages(hTransform);
                return;
            }
            System.out.println("PDF2AFP Transform run successfully");

            // Save output AFP memory buffer to local disk file
            byte[] pOutAFPBuf = PDF2AFP.getAFPStream(hTransform);
            outAFP = new java.io.FileOutputStream("mem.afp");
            outAFP.write(pOutAFPBuf);
            pOutAFPBuf = null;
        } catch (Throwable e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (outAFP != null) {
                    outAFP.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            // Release and close the converter
            PDF2AFP.closeTransform(hTransform);
        }
    }

    protected static void printTransMessages(long hTransform) {
        int nMsgCount = PDF2AFP.getErrorCount(hTransform);
        for (int i = 0; i < nMsgCount; ++i) {
            String sError = PDF2AFP.getError(hTransform, i);
            System.out.printf("* %d - %s\n", i + 1, sError);
        }
    }
}

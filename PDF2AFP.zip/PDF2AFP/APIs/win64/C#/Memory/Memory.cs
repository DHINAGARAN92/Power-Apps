﻿
// 2015.06.12 by MakeAFP.

using System;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using MakeAFP;

namespace P2AAPI
{
    class Memory
    {
        /// <summary>
        /// Main entry. You can set PDF2AFP Transform install path to your PATH system variable
        /// such as in command line: set PATH=C:\PDF2AFP;%PATH%, then run memory.exe
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            // In order to use data stream function, read AFP file to memory buffer
            byte[] pInPDFBuf = null;
            try
            {
                using (FileStream fs = File.OpenRead(@"c:\pdf2afp\test\insure.pdf"))
                {
                    int nFileSize = (int)fs.Length;
                    pInPDFBuf = new byte[nFileSize];
                    fs.Read(pInPDFBuf, 0, nFileSize);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return;
            }

            // Initialize PDF2AFP Transform from memory buffer
            StringBuilder sError = new StringBuilder(1024);
            string sArgs = "";   // You can set command arguments or null
            IntPtr pOutAFPBuf = IntPtr.Zero;
            int nOutAFPSize = 0;
            IntPtr hTransform = pdf2afp.P2AInitTransStream(sArgs, pInPDFBuf, pInPDFBuf.Length, ref pOutAFPBuf, ref nOutAFPSize, sError);
	        if (hTransform == IntPtr.Zero)
	        {
		        Console.WriteLine("Initialize PDF2AFP Transform failed: {0}", sError);
		        return;
	        }

	        // Start PDF2AFP Transform
	        int nReturnCode = pdf2afp.P2AStartTransform(hTransform);
	        if (nReturnCode >= 8)  // Ignore warning messages
	        {
		        Console.WriteLine("PDF2AFP Transform failed:");
		        _PrintTransMessages(hTransform);
		        pdf2afp.P2ACloseTransform(hTransform);
		        return;
            }
            Console.WriteLine("PDF2AFP Transform run successfully");
            pInPDFBuf = null;

            // Save output PDF memory buffer to local disk file
            try
            {
                byte[] pWriteBuf = new byte[4096];
                using (FileStream fs = File.OpenWrite("mem.afp"))
                {
                    while (nOutAFPSize > 0)
                    {
                        int nEachWrites = Math.Min(nOutAFPSize, 4096);
                        Marshal.Copy(pOutAFPBuf, pWriteBuf, 0, nEachWrites);
                        fs.Write(pWriteBuf, 0, nEachWrites);

                        pOutAFPBuf += nEachWrites;
                        nOutAFPSize -= nEachWrites;
                    }
                }
                pWriteBuf = null;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

	        // Release and close the converter
	        pdf2afp.P2ACloseTransform(hTransform);
	        return;
        }

        /// <summary>
        /// Print PDF2AFP Transform warning and error messages
        /// </summary>
        /// <param name="hTransform">PDF2AFP Transform handle</param>
        static void _PrintTransMessages(IntPtr hTransform)
        {
            StringBuilder sError = new StringBuilder(1024);
            int nMsgCount = pdf2afp.P2AGetErrorCount(hTransform);
            for (int i = 0; i < nMsgCount; ++i)
            {
                pdf2afp.P2AGetError(hTransform, i, sError, 1024);
                Console.WriteLine("* {0} - {1}", i + 1, sError);
            }
            sError = null;
        }
    }
}

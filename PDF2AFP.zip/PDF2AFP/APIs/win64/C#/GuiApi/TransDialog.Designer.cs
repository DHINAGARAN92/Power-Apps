﻿namespace GuiApi
{
    partial class TransDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.m_lblState = new System.Windows.Forms.Label();
            this.m_edtState = new System.Windows.Forms.TextBox();
            this.m_lblPDF = new System.Windows.Forms.Label();
            this.m_edtPDF = new System.Windows.Forms.TextBox();
            this.m_edtAFP = new System.Windows.Forms.TextBox();
            this.m_lblAFP = new System.Windows.Forms.Label();
            this.m_prbCurrent = new System.Windows.Forms.ProgressBar();
            this.m_lblCurrent = new System.Windows.Forms.Label();
            this.m_lblTotal = new System.Windows.Forms.Label();
            this.m_prbTotal = new System.Windows.Forms.ProgressBar();
            this.m_btnCancel = new System.Windows.Forms.Button();
            this.m_lblMsg = new System.Windows.Forms.Label();
            this.m_lbxMsg = new System.Windows.Forms.ListBox();
            this.m_tmTick = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // m_lblState
            // 
            this.m_lblState.AutoSize = true;
            this.m_lblState.Location = new System.Drawing.Point(14, 31);
            this.m_lblState.Name = "m_lblState";
            this.m_lblState.Size = new System.Drawing.Size(68, 25);
            this.m_lblState.TabIndex = 0;
            this.m_lblState.Text = "State:";
            // 
            // m_edtState
            // 
            this.m_edtState.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_edtState.Location = new System.Drawing.Point(104, 27);
            this.m_edtState.Name = "m_edtState";
            this.m_edtState.ReadOnly = true;
            this.m_edtState.Size = new System.Drawing.Size(567, 31);
            this.m_edtState.TabIndex = 1;
            // 
            // m_lblPDF
            // 
            this.m_lblPDF.AutoSize = true;
            this.m_lblPDF.Location = new System.Drawing.Point(14, 82);
            this.m_lblPDF.Name = "m_lblPDF";
            this.m_lblPDF.Size = new System.Drawing.Size(60, 25);
            this.m_lblPDF.TabIndex = 2;
            this.m_lblPDF.Text = "PDF:";
            // 
            // m_edtPDF
            // 
            this.m_edtPDF.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_edtPDF.Location = new System.Drawing.Point(104, 80);
            this.m_edtPDF.Name = "m_edtPDF";
            this.m_edtPDF.ReadOnly = true;
            this.m_edtPDF.Size = new System.Drawing.Size(567, 31);
            this.m_edtPDF.TabIndex = 3;
            // 
            // m_edtAFP
            // 
            this.m_edtAFP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_edtAFP.Location = new System.Drawing.Point(104, 130);
            this.m_edtAFP.Name = "m_edtAFP";
            this.m_edtAFP.ReadOnly = true;
            this.m_edtAFP.Size = new System.Drawing.Size(567, 31);
            this.m_edtAFP.TabIndex = 5;
            // 
            // m_lblAFP
            // 
            this.m_lblAFP.AutoSize = true;
            this.m_lblAFP.Location = new System.Drawing.Point(14, 132);
            this.m_lblAFP.Name = "m_lblAFP";
            this.m_lblAFP.Size = new System.Drawing.Size(59, 25);
            this.m_lblAFP.TabIndex = 4;
            this.m_lblAFP.Text = "AFP:";
            // 
            // m_prbCurrent
            // 
            this.m_prbCurrent.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_prbCurrent.Location = new System.Drawing.Point(104, 561);
            this.m_prbCurrent.Name = "m_prbCurrent";
            this.m_prbCurrent.Size = new System.Drawing.Size(567, 35);
            this.m_prbCurrent.TabIndex = 9;
            // 
            // m_lblCurrent
            // 
            this.m_lblCurrent.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.m_lblCurrent.AutoSize = true;
            this.m_lblCurrent.Location = new System.Drawing.Point(14, 567);
            this.m_lblCurrent.Name = "m_lblCurrent";
            this.m_lblCurrent.Size = new System.Drawing.Size(89, 25);
            this.m_lblCurrent.TabIndex = 8;
            this.m_lblCurrent.Text = "Current:";
            // 
            // m_lblTotal
            // 
            this.m_lblTotal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.m_lblTotal.AutoSize = true;
            this.m_lblTotal.Location = new System.Drawing.Point(14, 616);
            this.m_lblTotal.Name = "m_lblTotal";
            this.m_lblTotal.Size = new System.Drawing.Size(66, 25);
            this.m_lblTotal.TabIndex = 10;
            this.m_lblTotal.Text = "Total:";
            // 
            // m_prbTotal
            // 
            this.m_prbTotal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_prbTotal.Location = new System.Drawing.Point(104, 610);
            this.m_prbTotal.Name = "m_prbTotal";
            this.m_prbTotal.Size = new System.Drawing.Size(567, 35);
            this.m_prbTotal.TabIndex = 11;
            // 
            // m_btnCancel
            // 
            this.m_btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btnCancel.AutoSize = true;
            this.m_btnCancel.Enabled = false;
            this.m_btnCancel.Location = new System.Drawing.Point(277, 672);
            this.m_btnCancel.Name = "m_btnCancel";
            this.m_btnCancel.Size = new System.Drawing.Size(137, 35);
            this.m_btnCancel.TabIndex = 12;
            this.m_btnCancel.Text = "Cancel";
            this.m_btnCancel.UseVisualStyleBackColor = true;
            this.m_btnCancel.Click += new System.EventHandler(this.m_btnCancel_Click);
            // 
            // m_lblMsg
            // 
            this.m_lblMsg.AutoSize = true;
            this.m_lblMsg.Location = new System.Drawing.Point(14, 176);
            this.m_lblMsg.Name = "m_lblMsg";
            this.m_lblMsg.Size = new System.Drawing.Size(117, 25);
            this.m_lblMsg.TabIndex = 6;
            this.m_lblMsg.Text = "Messages:";
            // 
            // m_lbxMsg
            // 
            this.m_lbxMsg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_lbxMsg.FormattingEnabled = true;
            this.m_lbxMsg.ItemHeight = 25;
            this.m_lbxMsg.Location = new System.Drawing.Point(17, 213);
            this.m_lbxMsg.Name = "m_lbxMsg";
            this.m_lbxMsg.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.m_lbxMsg.Size = new System.Drawing.Size(654, 329);
            this.m_lbxMsg.TabIndex = 7;
            // 
            // m_tmTick
            // 
            this.m_tmTick.Interval = 500;
            this.m_tmTick.Tick += new System.EventHandler(this.m_tmTick_Tick);
            // 
            // TransDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(690, 733);
            this.Controls.Add(this.m_lbxMsg);
            this.Controls.Add(this.m_lblMsg);
            this.Controls.Add(this.m_btnCancel);
            this.Controls.Add(this.m_lblTotal);
            this.Controls.Add(this.m_prbTotal);
            this.Controls.Add(this.m_lblCurrent);
            this.Controls.Add(this.m_prbCurrent);
            this.Controls.Add(this.m_edtAFP);
            this.Controls.Add(this.m_lblAFP);
            this.Controls.Add(this.m_edtPDF);
            this.Controls.Add(this.m_lblPDF);
            this.Controls.Add(this.m_edtState);
            this.Controls.Add(this.m_lblState);
            this.Name = "TransDialog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "PDF2AFP Transforming";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ProgressDialog_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label m_lblState;
        private System.Windows.Forms.TextBox m_edtState;
        private System.Windows.Forms.Label m_lblPDF;
        private System.Windows.Forms.TextBox m_edtPDF;
        private System.Windows.Forms.TextBox m_edtAFP;
        private System.Windows.Forms.Label m_lblAFP;
        private System.Windows.Forms.ProgressBar m_prbCurrent;
        private System.Windows.Forms.Label m_lblCurrent;
        private System.Windows.Forms.Label m_lblTotal;
        private System.Windows.Forms.ProgressBar m_prbTotal;
        private System.Windows.Forms.Button m_btnCancel;
        private System.Windows.Forms.Label m_lblMsg;
        private System.Windows.Forms.ListBox m_lbxMsg;
        private System.Windows.Forms.Timer m_tmTick;
    }
}
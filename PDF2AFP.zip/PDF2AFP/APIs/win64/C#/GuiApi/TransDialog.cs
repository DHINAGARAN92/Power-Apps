﻿
// 2015.06.12 by MakeAFP.

using System;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using MakeAFP;

namespace GuiApi
{
    public partial class TransDialog : Form
    {
        protected IntPtr m_hTransform = IntPtr.Zero;
        protected int m_nLastMsgCount = 0;
        protected static string[] STATE_TEXT = { "Unknown", "Ready", "Running", "Abort", "Canceled", "Completed" };

        public TransDialog()
        {
            InitializeComponent();
        }

        private void ProgressDialog_FormClosed(object sender, FormClosedEventArgs e)
        {   
            m_tmTick.Enabled = false;
            if (m_hTransform != IntPtr.Zero)
            {
                Thread.Sleep(100);
                pdf2afp.P2ACloseTransform(m_hTransform);
                m_hTransform = IntPtr.Zero;
            }
        }

        private void m_tmTick_Tick(object sender, EventArgs e)
        {
            _UpdateControls();
        }

        private void m_btnCancel_Click(object sender, EventArgs e)
        {
            if (m_hTransform == IntPtr.Zero)
                return;

            pdf2afp.P2ACancelTransform(m_hTransform);

            // Waiting PDF2AFP transforming task to stop
            int nWaitCount = 10;
            pdf2afp.TP2AStateInfo si = new pdf2afp.TP2AStateInfo();
            pdf2afp.P2AQueryState(m_hTransform, ref si);
            while (nWaitCount > 0
                && (si.eState == pdf2afp.EP2AState.EP2AS_RUNNING
                  || si.eState == pdf2afp.EP2AState.EP2AS_READY))
            {
                Thread.Sleep(100);
                --nWaitCount;
            }
            _UpdateControls();
        }

        public void SetTransform(IntPtr hTransform)
        {
            m_hTransform = hTransform;
            _UpdateControls();
            m_tmTick.Enabled = true;
            m_btnCancel.Enabled = true;

            // Start PDF2AFP Transform thread
            ThreadStart ts = new ThreadStart(this._DoTransTask);
            Thread th = new Thread(ts);
            th.Start();
            Thread.Sleep(100);
        }

        protected void _DoTransTask()
        {
            pdf2afp.P2AStartTransform(m_hTransform);
        }

        private void _UpdateControls()
        {
            pdf2afp.TP2AStateInfo si = new pdf2afp.TP2AStateInfo();
            pdf2afp.P2AQueryState(m_hTransform, ref si);
            m_edtState.Text = STATE_TEXT[(int)si.eState];
            m_edtPDF.Text = si.sSrcPDF;
            m_edtAFP.Text = si.sDstAFP;
            m_prbCurrent.Value = si.nProgress;
            m_prbTotal.Value = si.nTotalProgress;

            int nMsgCount = pdf2afp.P2AGetErrorCount(m_hTransform);
            if (nMsgCount > m_nLastMsgCount)
            {
                StringBuilder sMsg = new StringBuilder(1024);
                for (int i = m_nLastMsgCount; i < nMsgCount; ++i)
                {
                    pdf2afp.P2AGetError(m_hTransform, i, sMsg, 1024);
                    m_lbxMsg.Items.Add(sMsg);
                }
                sMsg = null;
                m_nLastMsgCount = nMsgCount;
            }

            // PDF2AFP Transform abort or completed
            if ( si.eState == pdf2afp.EP2AState.EP2AS_ABORT
              || si.eState == pdf2afp.EP2AState.EP2AS_CANCELED
              || si.eState == pdf2afp.EP2AState.EP2AS_COMPLETED )
            {
                if (m_tmTick.Enabled)
                    m_tmTick.Enabled = false;
                if (m_btnCancel.Enabled)
                    m_btnCancel.Enabled = false;
            }
        }
    }
}

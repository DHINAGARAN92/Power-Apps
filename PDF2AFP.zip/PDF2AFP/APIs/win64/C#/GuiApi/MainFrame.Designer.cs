﻿namespace GuiApi
{
    partial class MainFrame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_edtPDFDir = new System.Windows.Forms.TextBox();
            this.m_lblPDFDir = new System.Windows.Forms.Label();
            this.m_btnPDFBrowser = new System.Windows.Forms.Button();
            this.m_btnAFPBrowser = new System.Windows.Forms.Button();
            this.m_lblAFPDir = new System.Windows.Forms.Label();
            this.m_edtAFPDir = new System.Windows.Forms.TextBox();
            this.m_btnStart = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // m_edtPDFDir
            // 
            this.m_edtPDFDir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_edtPDFDir.Location = new System.Drawing.Point(182, 37);
            this.m_edtPDFDir.Name = "m_edtPDFDir";
            this.m_edtPDFDir.Size = new System.Drawing.Size(423, 31);
            this.m_edtPDFDir.TabIndex = 1;
            // 
            // m_lblPDFDir
            // 
            this.m_lblPDFDir.AutoSize = true;
            this.m_lblPDFDir.Location = new System.Drawing.Point(16, 37);
            this.m_lblPDFDir.Name = "m_lblPDFDir";
            this.m_lblPDFDir.Size = new System.Drawing.Size(152, 25);
            this.m_lblPDFDir.TabIndex = 0;
            this.m_lblPDFDir.Text = "PDF Directory:";
            // 
            // m_btnPDFBrowser
            // 
            this.m_btnPDFBrowser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btnPDFBrowser.AutoSize = true;
            this.m_btnPDFBrowser.Location = new System.Drawing.Point(616, 35);
            this.m_btnPDFBrowser.Name = "m_btnPDFBrowser";
            this.m_btnPDFBrowser.Size = new System.Drawing.Size(46, 35);
            this.m_btnPDFBrowser.TabIndex = 2;
            this.m_btnPDFBrowser.Text = "...";
            this.m_btnPDFBrowser.UseVisualStyleBackColor = true;
            this.m_btnPDFBrowser.Click += new System.EventHandler(this.m_btnPDFBrowser_Click);
            // 
            // m_btnAFPBrowser
            // 
            this.m_btnAFPBrowser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btnAFPBrowser.AutoSize = true;
            this.m_btnAFPBrowser.Location = new System.Drawing.Point(616, 91);
            this.m_btnAFPBrowser.Name = "m_btnAFPBrowser";
            this.m_btnAFPBrowser.Size = new System.Drawing.Size(46, 35);
            this.m_btnAFPBrowser.TabIndex = 5;
            this.m_btnAFPBrowser.Text = "...";
            this.m_btnAFPBrowser.UseVisualStyleBackColor = true;
            this.m_btnAFPBrowser.Click += new System.EventHandler(this.m_btnAFPBrowser_Click);
            // 
            // m_lblAFPDir
            // 
            this.m_lblAFPDir.AutoSize = true;
            this.m_lblAFPDir.Location = new System.Drawing.Point(16, 93);
            this.m_lblAFPDir.Name = "m_lblAFPDir";
            this.m_lblAFPDir.Size = new System.Drawing.Size(151, 25);
            this.m_lblAFPDir.TabIndex = 3;
            this.m_lblAFPDir.Text = "AFP Directory:";
            // 
            // m_edtAFPDir
            // 
            this.m_edtAFPDir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.m_edtAFPDir.Location = new System.Drawing.Point(182, 93);
            this.m_edtAFPDir.Name = "m_edtAFPDir";
            this.m_edtAFPDir.Size = new System.Drawing.Size(423, 31);
            this.m_edtAFPDir.TabIndex = 4;
            // 
            // m_btnStart
            // 
            this.m_btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.m_btnStart.AutoSize = true;
            this.m_btnStart.Location = new System.Drawing.Point(511, 167);
            this.m_btnStart.Name = "m_btnStart";
            this.m_btnStart.Size = new System.Drawing.Size(151, 35);
            this.m_btnStart.TabIndex = 7;
            this.m_btnStart.Text = "Start";
            this.m_btnStart.UseVisualStyleBackColor = true;
            this.m_btnStart.Click += new System.EventHandler(this.m_btnStart_Click);
            // 
            // MainFrame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(681, 230);
            this.Controls.Add(this.m_btnStart);
            this.Controls.Add(this.m_btnAFPBrowser);
            this.Controls.Add(this.m_lblAFPDir);
            this.Controls.Add(this.m_edtAFPDir);
            this.Controls.Add(this.m_btnPDFBrowser);
            this.Controls.Add(this.m_lblPDFDir);
            this.Controls.Add(this.m_edtPDFDir);
            this.Name = "MainFrame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MakeAFP PDF2AFP Transform API Test";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox m_edtPDFDir;
        private System.Windows.Forms.Label m_lblPDFDir;
        private System.Windows.Forms.Button m_btnPDFBrowser;
        private System.Windows.Forms.Button m_btnAFPBrowser;
        private System.Windows.Forms.Label m_lblAFPDir;
        private System.Windows.Forms.TextBox m_edtAFPDir;
        private System.Windows.Forms.Button m_btnStart;
    }
}


﻿
// 2015.06.12 by MakeAFP.

using System;
using System.IO;
using System.Text;
using System.Windows.Forms;
using MakeAFP;

namespace GuiApi
{
    public partial class MainFrame : Form
    {
        public MainFrame()
        {
            InitializeComponent();

            m_edtPDFDir.Text = @"c:\pdf2afp\test";
        }

        private void m_btnPDFBrowser_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            dlg.Description = "Select an input PDF directory";
            dlg.SelectedPath = m_edtPDFDir.Text;
            if (dlg.ShowDialog(this) == DialogResult.OK)
                m_edtPDFDir.Text = dlg.SelectedPath;
        }

        private void m_btnAFPBrowser_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            dlg.Description = "Select an output AFP directory";
            dlg.SelectedPath = m_edtAFPDir.Text;
            if (dlg.ShowDialog(this) == DialogResult.OK)
                m_edtAFPDir.Text = dlg.SelectedPath;
        }

        private void m_btnStart_Click(object sender, EventArgs e)
        {
            // Set PDF2AFP Transform command arguments
            string sInPDFDir = m_edtPDFDir.Text;
            sInPDFDir.Trim();
            if (!Directory.Exists(sInPDFDir))
            {
                MessageBox.Show("Invalid input PDF directory");
                m_edtPDFDir.Focus();
                return;
            }
            string sArgs = string.Format("-i \"{0}\"", sInPDFDir);

            string sOutAFPDir = m_edtAFPDir.Text;
            sOutAFPDir.Trim();
            if (!string.IsNullOrEmpty(sOutAFPDir))
                sArgs += string.Format(" -o \"{0}\"", sOutAFPDir);

            // Initialize PDF2AFP Transform
            StringBuilder sError = new StringBuilder(1024);
            IntPtr hTransform = pdf2afp.P2AInitTransform(sArgs, sError);
            if (hTransform == IntPtr.Zero)
            {
                MessageBox.Show(string.Format("Initialize PDF2AFP Transform failed: {0}", sError));
                return;
            }

            // Show transforming progress
            TransDialog dlg = new TransDialog();
            dlg.SetTransform(hTransform);
            dlg.ShowDialog(this);
            dlg = null;
        }
    }
}

﻿
/******************************************************************************
* MakeAFP PDF2AFP Transform API for Windows .NET platform
*
* Copyright (C) 2018, MakeAFP Inc. All rights reserved.
* Created: 2018.06.05
 *****************************************************************************/

using System;
using System.Text;
using System.Runtime.InteropServices;

namespace MakeAFP
{
    public sealed class pdf2afp
    {
        public const int P2A_MAXPATH = 512;

        /// <summary>
        /// States of PDF2AFP Transform
        /// </summary>
        public enum EP2AState
        {
            EP2AS_UNKNOWN,    // Unknown state
            EP2AS_READY,      // PDF2AFP Transform is ready
            EP2AS_RUNNING,    // PDF2AFP Transform is running
            EP2AS_ABORT,      // PDF2AFP Transform has encountered some serious problems, was forced to abort
            EP2AS_CANCELED,   // PDF2AFP Transform has been canceled by P2ACancelTransform
            EP2AS_COMPLETED,  // PDF2AFP Transform has completed the task
        }

        /// <summary>
        /// The transforming state and information
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode, Pack = 1)]
        public struct TP2AStateInfo
        {
            public EP2AState eState;     // Real-time state of the current PDF2AFP Transform
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = P2A_MAXPATH)]
            public string sSrcPDF;       // Current source PDF filename
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = P2A_MAXPATH)]
            public string sDstAFP;       // Current destination AFP filename
            public byte nProgress;       // Current transforming progress of the source PDF file, value range[0-100]
            public byte nTotalProgress;  // Total progress was used while transforming multiple PDF files
        }

        /// <summary>
        /// Initializes PDF2AFP Transform to read AFP from a file
        /// </summary>
        /// <param name="sArgs">PDF2AFP command-line argument flags</param>
        /// <param name="sError">Error messages, its buffer size recommended is above 1024</param>
        /// <returns>PDF2AFP Transform handle. If the function fails, then return value is NULL</returns>
        [DllImport("PDF2AFP.dll")]
        public static extern IntPtr P2AInitTransform(
            [MarshalAs(UnmanagedType.LPWStr)]string sArgs,
            [MarshalAs(UnmanagedType.LPWStr)]StringBuilder sError);

        /// <summary>
        /// Initializes PDF2AFP Transform to read AFP data stream from a memory buffer
        /// </summary>
        /// <param name="sArgs">PDF2AFP command-line argument flags</param>
        /// <param name="pInPDFBuffer">Input PDF data stream buffer</param>
        /// <param name="nPDFBufSize">Size of input PDF data stream</param>
        /// <param name="pOutAFPBuffer">Output AFP data stream buffer</param>
        /// <param name="nOutAFPBufSize">Size of output AFP data stream</param>
        /// <param name="sError">Error messages, its buffer size recommended is above 1024</param>
        /// <returns>PDF2AFP Transform handle. If the function fails, then return value is NULL</returns>
        [DllImport("PDF2AFP.dll")]
        public static extern IntPtr P2AInitTransStream(
            [MarshalAs(UnmanagedType.LPWStr)]string sArgs,
            [MarshalAs(UnmanagedType.LPArray)]byte[] pInPDFBuffer,
            Int32 nPDFBufSize, ref IntPtr pOutAFPBuffer, ref Int32 nOutAFPBufSize,
            [MarshalAs(UnmanagedType.LPWStr)]StringBuilder sError);

        /// <summary>
        /// Start PDF2AFP transforming task
        /// </summary>
        /// <param name="hTransform"></param>
        /// <returns>0 - successful; 4 - warnings; 8 - errors; 12 - warnings and errors</returns>
        [DllImport("PDF2AFP.dll")]
        public static extern Int32 P2AStartTransform(IntPtr hTransform);
        
        /// <summary>
        /// Query the current running state of PDF2AFP Transform
        /// </summary>
        /// <param name="hTransform">Handle returned by P2AInitTransform or P2AInitTransStream function</param>
        /// <param name="tStateInfo">PDF2AFP Transform state information</param>
        /// <returns></returns>
        [DllImport("PDF2AFP.dll")]
        public static extern Int32 P2AQueryState(IntPtr hTransform, ref TP2AStateInfo tStateInfo);

        /// <summary>
        /// Get the count of warning and error messages
        /// </summary>
        /// <param name="hTransform">Handle returned by P2AInitTransform or P2AInitTransStream function</param>
        /// <returns></returns>
        [DllImport("PDF2AFP.dll")]
        public static extern Int32 P2AGetErrorCount(IntPtr hTransform);

        /// <summary>
        /// Get the specified warning or error message
        /// </summary>
        /// <param name="hTransform">Handle returned by P2AInitTransform or P2AInitTransStream function</param>
        /// <param name="nErrorIndex">Zero-based index of errors</param>
        /// <param name="sBuffer">Retrieve the error messages</param>
        /// <param name="dwSize">Specifies the maximum buffer size,</param>
        /// <returns></returns>
        [DllImport("PDF2AFP.dll")]
        public static extern IntPtr P2AGetError(IntPtr hTransform, Int32 nErrorIndex,
            [MarshalAs(UnmanagedType.LPWStr)]StringBuilder sBuffer, UInt32 dwSize);

        /// <summary>
        /// Cancel or stop current PDF2AFP transforming task
        /// </summary>
        /// <param name="hTransform">Handle returned by P2AInitTransform or P2AInitTransStream function</param>
        /// <returns></returns>
        [DllImport("PDF2AFP.dll")]
        public static extern int P2ACancelTransform(IntPtr hTransform);

        /// <summary>
        /// Close and release current PDF2AFP Transform handle
        /// </summary>
        /// <param name="hTransform">Handle returned by P2AInitTransform or P2AInitTransStream function</param>
        [DllImport("PDF2AFP.dll")]
        public static extern void P2ACloseTransform(IntPtr hTransform);
    }
}

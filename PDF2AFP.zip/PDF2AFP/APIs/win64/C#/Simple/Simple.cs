﻿
// 2015.06.09 by MakeAFP.

using System;
using System.Text;
using MakeAFP;

namespace P2AAPI
{
    class Simple
    {
        static void Main(string[] args)
        {
            // Initialize PDF2AFP Transform
            StringBuilder sError = new StringBuilder(1024);
            string sArgs = @"c:\pdf2afp\test\insure.pdf";
            IntPtr hTransform = pdf2afp.P2AInitTransform(sArgs, sError);
            if (hTransform == IntPtr.Zero)
            {
                Console.WriteLine("Initialize PDF2AFP Transform failed: {0}", sError);
                return;
            }

            // Start PDF2AFP Transform
            int nReturnCode = pdf2afp.P2AStartTransform(hTransform);
            if (nReturnCode >= 8)  // Ignore warning messages
            {
                Console.WriteLine("PDF2AFP Transform failed:");
                _PrintTransMessages(hTransform);
                pdf2afp.P2ACloseTransform(hTransform);
                return;
            }
            Console.WriteLine("PDF2AFP Transform run successfully");

            // Release and close the converter
            pdf2afp.P2ACloseTransform(hTransform);
            return;
        }

        /// <summary>
        /// Print PDF2AFP Transform warning and error messages
        /// </summary>
        /// <param name="hTransform">PDF2AFP Transform handle</param>
        static void _PrintTransMessages(IntPtr hTransform)
        {
            StringBuilder sError = new StringBuilder(1024);
            int nMsgCount = pdf2afp.P2AGetErrorCount(hTransform);
            for (int i = 0; i < nMsgCount; ++i)
            {
                pdf2afp.P2AGetError(hTransform, i, sError, 1024);
                Console.WriteLine("* {0} - {1}", i + 1, sError);
            }
            sError = null;
        }
    }
}

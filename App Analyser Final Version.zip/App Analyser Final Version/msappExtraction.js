window.viewMsappFiles = async function (uniqueName, documentUri) {
  if (!window.zipContent) {
    alert("No ZIP file loaded. Please upload a ZIP file first.");
    return;
  }

  try {
    console.log(`Extracting .msapp file for ${uniqueName} with Document URI: ${documentUri}`);

    const normalizedDocumentUri = documentUri.startsWith("/") ? documentUri.substring(1) : documentUri;
    const msappFile = Object.keys(window.zipContent.files).find((file) => file === normalizedDocumentUri);

    if (!msappFile) {
      alert(`File ${normalizedDocumentUri} not found in the ZIP.`);
      return;
    }

    const jszip = new JSZip();
    const msappBlob = await window.zipContent.files[msappFile].async("blob");
    const msappZipContent = await jszip.loadAsync(msappBlob);

    const sarifFile = Object.keys(msappZipContent.files).find((file) => file.endsWith("AppCheckerResult.sarif"));

    if (!sarifFile) {
      alert("No AppCheckerResult.sarif file found in the .msapp package.");
      return;
    }

    const sarifContent = await msappZipContent.files[sarifFile].async("string");

    // Pass SARIF content and unique name to the new page
    localStorage.setItem("sarifContent", sarifContent);
    localStorage.setItem("appName", uniqueName);

    // Open the SARIF Viewer page
    window.open("sarifViewer.html", "_blank");
  } catch (error) {
    console.error("Error processing .msapp file or SARIF file:", error);
  }
};

window.populateAppOverview = function (apps, connections, flows, zipFileName, sarifMetrics) {
  const appOverview = document.getElementById("canvas-app-overview");

  if (!appOverview) {
    console.error("App Overview container not found!");
    return;
  }

  // Extract file and version details
  const fileName = zipFileName || "N/A";
  const versionMatch = fileName.match(/_(\d+_\d+_\d+_\d+)_/);
  const version = versionMatch ? versionMatch[1].replace(/_/g, ".") : "N/A";
  const typeMatch = fileName.match(/_(managed|unmanaged)\.zip$/i);
  const versionType = typeMatch ? typeMatch[1] : "N/A";

  const totalApps = apps?.length || 0;
  const canvasApps = apps?.filter((app) => app.type === "Canvas").length || 0;
  const modelDrivenApps = apps?.filter((app) => app.type === "Model-Driven").length || 0;

  const totalConnections = connections?.length || 0;
  const totalFlows = flows?.length || 0;

  // Count Cloud Flows and BPFs
  const cloudFlows = flows?.filter((f) => f.type === "Cloud Flow") || [];
  const businessProcessFlows = flows?.filter((f) => f.type === "Business Process Flow") || [];

  // Count On and Off status for Cloud Flows
  const cloudFlowsOn = cloudFlows.filter((f) => f.status === "On").length;
  const cloudFlowsOff = cloudFlows.filter((f) => f.status === "Off").length;

  // Count On and Off status for Business Process Flows
  const bpfOn = businessProcessFlows.filter((f) => f.status === "On").length;
  const bpfOff = businessProcessFlows.filter((f) => f.status === "Off").length;

  // Generate status summary for Cloud Flows and BPFs with "On" and "Off" counts
  const cloudFlowsSummary = `Cloud Flows: <strong>${cloudFlows.length} ( ${cloudFlowsOn}-On, <span style="color: red;">${cloudFlowsOff}-Off</span> )</strong>`;
  const bpfSummary = `BPF: <strong>${businessProcessFlows.length} ( ${bpfOn}-On, <span style="color: red;">${bpfOff}-Off</span> )</strong>`;

  // Determine the health status based on sarifMetrics
  let healthStatus = "green"; // Default to green (excellent)
  if (sarifMetrics && Object.keys(sarifMetrics).length > 0) {
    const nonAccessibilityIssues = Object.entries(sarifMetrics).filter(([key, value]) => key.toLowerCase() !== "accessibility" && value > 0);
    if (nonAccessibilityIssues.length > 0) {
      healthStatus = "red"; // Poor if any non-accessibility issues exist
    } else if (sarifMetrics.accessibility > 0) {
      healthStatus = "yellow"; // Average if only accessibility issues exist
    }
  }

  const statusText = {
    green: "Healthy",
    yellow: "Attention Needed",
    red: "Critical Issues",
  };

  // Generate HTML for SARIF Metrics with hyperlinks for each category
  const metricsHtml = sarifMetrics
    ? Object.entries(sarifMetrics)
        .map(
          ([category, count]) =>
            `<a href="errorDetails.html?category=${encodeURIComponent(category.toLowerCase())}" 
              style="color: red; text-decoration: none;" 
              target="_blank">
            ${category}: ${count} items
          </a><br>`
        )
        .join("")
    : "<p>No SARIF data found</p>";

  // Populate the App Overview
  appOverview.innerHTML = `
    <div class="overview-container">
      <!-- Total Apps Card -->
      <div class="overview-card">
        <h3>
          <span style="margin-right: 8px;">📊</span>Total Apps
        </h3>
        <p><strong>${totalApps}</strong></p>
        <small>Canvas: ${canvasApps}, Model-Driven: ${modelDrivenApps}</small>
      </div>

      <!-- Connection References Card -->
      <div class="overview-card">
        <h3>
          <span style="margin-right: 8px;">🔗</span>Connection References
        </h3>
        <p><strong>${totalConnections}</strong></p>
      </div>

      <!-- Cloud Flows Card -->
      <div class="overview-card">
        <h3>
          <span style="margin-right: 8px;">☁️</span>Cloud Flows
        </h3>
        <p><strong>${totalFlows}</strong></p>
        <small>${cloudFlowsSummary}, ${bpfSummary}</small>
      </div>

      <!-- Package Details Card -->
      <div class="overview-card" style="text-align: left;">
        <h3>
          <span style="margin-right: 8px;">📦</span>Package Details
        </h3>
        <small><strong>File:</strong> ${fileName}</small><br>
        <small><strong>Version:</strong> ${version}</small><br>
        <small><strong>Type:</strong> ${versionType}</small>
      </div>

      <!-- Errors/Warnings Card -->
      <div class="overview-card">
        <h3 style="margin-bottom: 10px;">
          <span style="margin-right: 8px; color: #ffcc00;">⚠️</span>Errors/Warnings
        </h3>
        <div style="line-height: 1.6; font-size: 14px; text-align: center;">
          ${metricsHtml}
        </div>
      </div>

      <!-- Overall Health Card -->
      <div class="overview-card">
        <h3 style="margin-bottom: 10px;">
          <span style="margin-right: 8px;">💡</span>Overall Health
        </h3>
        <div 
          class="status-indicator" 
          style="background-color: ${healthStatus}; width: 40px; height: 40px; border-radius: 50%; margin: 10px auto;">
        </div>
        <p style="text-align: center; font-weight: bold; font-size: 16px; color: ${healthStatus};">
          ${statusText[healthStatus]}
        </p>
        <div class="legend" style="display: flex; justify-content: space-around; margin-top: 10px; font-size: 0.9rem;">
          <div style="display: flex; align-items: center; gap: 6px;">
            <span style="width: 12px; height: 12px; background-color: green; display: inline-block; border-radius: 3px;"></span> Healthy
          </div>
          <div style="display: flex; align-items: center; gap: 6px;">
            <span style="width: 12px; height: 12px; background-color: yellow; display: inline-block; border-radius: 3px;"></span> Attention Needed
          </div>
          <div style="display: flex; align-items: center; gap: 6px;">
            <span style="width: 12px; height: 12px; background-color: red; display: inline-block; border-radius: 3px;"></span> Critical Issues
          </div>
        </div>
      </div>
    </div>
  `;
};

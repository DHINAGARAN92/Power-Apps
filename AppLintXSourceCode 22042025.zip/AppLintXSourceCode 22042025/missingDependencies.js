document.addEventListener("DOMContentLoaded", function () {
  const menuMissingDependencies = document.getElementById("menu-missing-dependencies");

  if (menuMissingDependencies) {
    menuMissingDependencies.addEventListener("click", () => {
      setActiveMenuItem("menu-missing-dependencies");
      hideAllSections();
      document.getElementById("missing-dependencies").style.display = "block";
    });
  }
});

// Function to hide all sections
function hideAllSections() {
  const sections = [
    "dashboard",
    "app-details",
    "entity-details",
    "connection-references",
    "cloud-flows",
    "deployment-checklist",
    "environment-variables",
    "app-details-section",
    "missing-dependencies"
  ];
  sections.forEach(id => {
    const section = document.getElementById(id);
    if (section) section.style.display = "none";
  });
}

// Function to extract Missing Dependencies from `solution.xml`
async function extractMissingDependencies(zipContent) {
  try {
    // ✅ Check if `solution.xml` exists
    if (!zipContent.files["solution.xml"]) {
      console.warn("⚠️ solution.xml not found in ZIP.");
      populateMissingDependencies([]);
      return;
    }

    // ✅ Read the contents of `solution.xml`
    const solutionXmlContent = await zipContent.files["solution.xml"].async("string");

    // ✅ Parse the XML content
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(solutionXmlContent, "text/xml");

    // ✅ Extract Missing Dependencies
    const missingDependencies = Array.from(xmlDoc.querySelectorAll("MissingDependency")).map((dep) => {
      const required = dep.querySelector("Required");
      const dependent = dep.querySelector("Dependent");

      return {
        requiredName: required?.getAttribute("displayName") || "Unknown",
        requiredSchema: required?.getAttribute("schemaName") || "Unknown",
        requiredType: required?.getAttribute("type") || "Unknown",
        solutionName: required?.getAttribute("solution") || "Unknown",
        dependentName: dependent?.getAttribute("displayName") || "Unknown",
        dependentSchema: dependent?.getAttribute("schemaName") || "Unknown",
        dependentType: dependent?.getAttribute("type") || "Unknown",
      };
    });

    // ✅ Populate UI
    populateMissingDependencies(missingDependencies);
    console.log("✅ Extracted Missing Dependencies:", missingDependencies);

  } catch (error) {
    console.error("❌ Error extracting missing dependencies:", error);
  }
}

// Function to populate the Missing Dependencies table
function populateMissingDependencies(missingDependencies) {
  const tableContainer = document.getElementById("missing-dependencies-table");

  if (!tableContainer) {
    console.error("❌ Missing Dependencies table container not found.");
    return;
  }

  if (missingDependencies.length === 0) {
    tableContainer.innerHTML = "<p>No missing dependencies found! ✅</p>";
    return;
  }

  let html = `
    <table>
      <thead>
        <tr>
          <th>Required Dependency</th>
          <th>Schema Name</th>
          <th>Solution Name</th>
          <th>Dependent Component</th>
          <th>Dependent Schema</th>
        </tr>
      </thead>
      <tbody>
  `;

  missingDependencies.forEach(dep => {
    html += `
      <tr>
        <td>${dep.requiredName}</td>
        <td>${dep.requiredSchema}</td>
        <td>${dep.solutionName}</td>
        <td>${dep.dependentName}</td>
        <td>${dep.dependentSchema}</td>
      </tr>
    `;
  });

  html += "</tbody></table>";
  tableContainer.innerHTML = html;
}

// View and Extract .msapp Files
// View and Extract .msapp Files
window.viewMsappFiles = async function (uniqueName, documentUri) {
  if (!window.zipContent) {
    alert("No ZIP file loaded. Please upload a ZIP file first.");
    return;
  }

  try {
    console.log(`Extracting .msapp file for ${uniqueName} with Document URI: ${documentUri}`);

    // Log all available files in the ZIP for debugging
    console.log("Available files in ZIP:", Object.keys(window.zipContent.files));

    // Normalize the documentUri by removing any leading slash
    const normalizedDocumentUri = documentUri.startsWith("/")
      ? documentUri.substring(1)
      : documentUri;

    console.log(`Normalized Document URI: ${normalizedDocumentUri}`);

    // Locate the exact .msapp file
    const msappFile = Object.keys(window.zipContent.files).find(
      (file) => file === normalizedDocumentUri
    );

    if (!msappFile) {
      alert(`File ${normalizedDocumentUri} not found in the ZIP.`);
      console.warn("Available files in ZIP:", Object.keys(window.zipContent.files));
      return;
    }

    console.log(`Found .msapp file: ${msappFile}`);

    // Extract the .msapp file as a ZIP
    const jszip = new JSZip();
    const msappBlob = await window.zipContent.files[msappFile].async("blob");
    const msappZipContent = await jszip.loadAsync(msappBlob);

    // Log available files inside the .msapp ZIP
    console.log("Files inside .msapp:", Object.keys(msappZipContent.files));

    // Locate the SARIF file
    const sarifFile = Object.keys(msappZipContent.files).find((file) =>
      file.endsWith("AppCheckerResult.sarif")
    );

    if (!sarifFile) {
      alert("No AppCheckerResult.sarif file found inside the .msapp package.");
      console.warn("Files inside .msapp:", Object.keys(msappZipContent.files));
      return;
    }

    console.log(`Found SARIF file: ${sarifFile}`);

    // Extract and display SARIF content
    const sarifContent = await msappZipContent.files[sarifFile].async("string");
    displaySarifContent(sarifContent);
  } catch (error) {
    console.error("Error processing .msapp file or SARIF file:", error);
    alert("Failed to process the .msapp file or SARIF file.");
  }
};


// Display SARIF Content
function displaySarifContent(sarifContent) {
  const sarifData = JSON.parse(sarifContent);

  // Extract results from the SARIF data
  const results = sarifData.runs[0].results || [];

  const detailsContainer = document.getElementById("app-details-content");
  let sarifHtml = `
    <h3>App Issues/Warnings/Fix</h3>
    <table>
      <thead>
        <tr>
          <th>Rule ID</th>
          <th>Message</th>
          <th>Location</th>
          <th>Severity</th>
        </tr>
      </thead>
      <tbody>
        ${results
          .map((result) => {
            const ruleId = result.ruleId || "N/A";
            const message = result.message?.text || result.message?.id || "N/A";
            const location = result.locations[0]?.physicalLocation?.address?.fullyQualifiedName || "N/A";
            const severity = result.properties?.level || "N/A";
            return `
              <tr>
                <td>${ruleId}</td>
                <td>${message}</td>
                <td>${location}</td>
                <td>${severity}</td>
              </tr>
            `;
          })
          .join("")}
      </tbody>
    </table>
  `;

  detailsContainer.innerHTML = sarifHtml;

  // Show the details section
  const detailsSection = document.getElementById("app-details-section");
  detailsSection.style.display = "block";

  // Hide other sections
  const otherSections = ["dashboard", "entity-details", "connection-references", "cloud-flows"];
  otherSections.forEach((id) => document.getElementById(id).style.display = "none");
}

// Back to App Details
window.backToAppDetails = function () {
  const detailsSection = document.getElementById("app-details-section");
  detailsSection.style.display = "none";

  // Show the app details table
  const appDetails = document.getElementById("app-details");
  appDetails.style.display = "block";
};

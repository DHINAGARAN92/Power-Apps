chrome.runtime.onInstalled.addListener(() => {
  console.log("Fake Filler Extension Installed!");
});

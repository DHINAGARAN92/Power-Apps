document.addEventListener("DOMContentLoaded", () => {
  const fillBtn = document.getElementById("fillForm");
  fillBtn.addEventListener("click", async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const url = tab.url.toLowerCase();
    if (!(url.includes("crm.dynamics.com") || url.includes("make.powerapps.com"))) {
      alert("This page is not supported. Please open a Dynamics CRM or PowerApps page.");
      return;
    }
    chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      func: () => {
        if (typeof window.fillForm === "function") {
          window.fillForm();
        } else {
          console.error("fillForm is not defined in this frame.");
        }
      }
    }, (results) => {
      if (chrome.runtime.lastError) {
        console.error("Execution error:", chrome.runtime.lastError.message);
      } else {
        console.log("Fill Form executed in all frames:", results);
      }
    });
  });
});

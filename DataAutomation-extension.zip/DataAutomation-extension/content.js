(function () {
  // ------------------------------
  // Date Formatting Helper
  // ------------------------------
  function getCurrentDateFormatted() {
    const now = new Date();
    const month = (now.getMonth() + 1).toString().padStart(2, '0'); // two-digit month
    const day = now.getDate();
    const year = now.getFullYear();
    return `${month}/${day}/${year}`;
  }

  // ------------------------------
  // Field Type Detection
  // ------------------------------
  function getFieldDataType(field) {
    let dataType = field.getAttribute("data-fieldtype") || field.getAttribute("data-datatype");
    if (dataType) return dataType.toLowerCase();

    const ariaLabel = field.getAttribute("aria-label");
    if (ariaLabel) {
      const lowerLabel = ariaLabel.toLowerCase();
      if (lowerLabel.includes("currency")) return "currency";
      if (lowerLabel.includes("date")) return "datetime";
      if (lowerLabel.includes("number")) return "number";
      if (lowerLabel.includes("email")) return "email";
      if (lowerLabel.includes("choice")) return "choice";
      if (lowerLabel.includes("lookup")) return "lookup";
    }

    if (field.placeholder) {
      const ph = field.placeholder.toLowerCase();
      if (ph.includes("date") || ph.includes("time")) return "datetime";
      if (ph.includes("number")) return "number";
      if (ph.includes("email")) return "email";
    }

    return field.type ? field.type.toLowerCase() : "text";
  }

  // ------------------------------
  // Dummy Data Generation
  // ------------------------------
  function generateDummyData(type) {
    const names = ["John Doe", "Jane Smith", "Alice Johnson"];
    const emails = ["test@example.com", "user@mail.com", "fake@demo.com"];
    const numbers = [123, 456, 789];
    const currencies = ["100.50", "2500.75", "9999.99"];
    const choices = ["Option A", "Option B", "Option C"];

    switch (type) {
      case "text":
        return names[Math.floor(Math.random() * names.length)];
      case "email":
        return emails[Math.floor(Math.random() * emails.length)];
      case "tel":
      case "phone":
        return numbers[Math.floor(Math.random() * numbers.length)].toString();
      case "number":
        return numbers[Math.floor(Math.random() * numbers.length)];
      case "currency":
        return currencies[Math.floor(Math.random() * currencies.length)];
      case "choice":
        return choices[Math.floor(Math.random() * choices.length)];
      case "file":
        return ""; 
      default:
        return "Lorem Ipsum";
    }
  }

  // ------------------------------
  // Date Field Setter
  // ------------------------------
  function setDateField(field) {
    const currentDate = getCurrentDateFormatted();
    field.value = currentDate;
    field.defaultValue = currentDate;
    field.setAttribute("value", currentDate);
    field.dispatchEvent(new Event("input", { bubbles: true }));
    field.dispatchEvent(new Event("change", { bubbles: true }));
    field.dispatchEvent(new Event("blur", { bubbles: true }));
    field.dispatchEvent(new Event("focusout", { bubbles: true }));
  }

  // ------------------------------
  // Main Form-Filling Function
  // ------------------------------
  function fillPowerAppsForm() {
    document.querySelectorAll("input, textarea, select").forEach((field) => {
      const dataType = getFieldDataType(field);
      if (dataType === "submit" || dataType === "button") return;
      if (dataType === "lookup") return;

      if (dataType === "datetime" || dataType === "datetime-local" || dataType === "date") {
        setDateField(field);
      } else if (dataType === "file") {
        console.log("File input detected. Please upload manually.");
      } else if (field.tagName.toLowerCase() === "select") {
        const options = field.options;
        if (options.length > 1) {
          const randomIndex = Math.floor(Math.random() * options.length);
          field.selectedIndex = randomIndex;
          field.dispatchEvent(new Event("change", { bubbles: true }));
        }
      } else {
        field.value = generateDummyData(dataType);
        field.dispatchEvent(new Event("input", { bubbles: true }));
        field.dispatchEvent(new Event("change", { bubbles: true }));
        field.dispatchEvent(new Event("blur", { bubbles: true }));
      }
    });
  }

  // ------------------------------
  // Tab Activation with Retry
  // ------------------------------
  function activateAllTabsAndFill() {
    const tabHeaders = document.querySelectorAll("ul[role='tablist'] li[role='tab']");
    if (!tabHeaders.length) {
      console.log("No tab headers found.");
      return;
    }
    let delay = 0;
    tabHeaders.forEach((tabHeader, index) => {
      setTimeout(() => {
        console.log(`Activating tab ${index + 1}: ${tabHeader.textContent.trim()}`);
        tabHeader.click();
        attemptFill(3, 1000);
      }, delay);
      delay += 2000;
    });

    // After all tabs are filled, show a notification
    setTimeout(showCompletionNotification, delay + 2000);
  }

  // attemptFill: Retries filling the active tab's fields 'retries' times with 'interval' delay.
  function attemptFill(retries, interval) {
    if (retries <= 0) return;
    setTimeout(() => {
      console.log("Attempting to fill active tab...");
      fillPowerAppsForm();
      attemptFill(retries - 1, interval);
    }, interval);
  }

  // ------------------------------
  // Show Notification After Completion
  // ------------------------------
  function showCompletionNotification() {
    if (chrome.notifications) {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icon.png",
        title: "Fake Filler",
        message: "Form filled successfully in all tabs!",
        priority: 2
      });
    } else {
      alert("Form filled successfully in all tabs!");
    }
  }

  // ------------------------------
  // Entry Point: fillForm()
  // ------------------------------
  function fillForm() {
    const url = window.location.href.toLowerCase();
    if (!(url.includes("crm.dynamics.com") || url.includes("make.powerapps.com"))) {
      console.log("This is not a supported Dynamics CRM or PowerApps page. Aborting fill form.");
      return;
    }
    fillPowerAppsForm();
    activateAllTabsAndFill();
  }

  // ------------------------------
  // Message Listener
  // ------------------------------
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "fillForm") {
      fillForm();
      sendResponse({ status: "filled" });
    }
  });

  // Expose fillForm globally
  window.fillForm = fillForm;
})();

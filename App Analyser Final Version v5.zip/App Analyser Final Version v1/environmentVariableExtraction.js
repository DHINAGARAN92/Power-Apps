document.getElementById("menu-environment-variables").addEventListener("click", async () => {
  if (!window.zipContent) {
    alert("No ZIP file loaded. Please upload a ZIP file first.");
    return;
  }
  await window.populateEnvironmentVariables(window.zipContent);
});

// Function to extract environment variables from the ZIP file
async function extractEnvironmentVariables(zipContent) {
  try {
    // Ensure zipContent and files exist
    if (!zipContent || !zipContent.files) {
      throw new Error("ZIP content or files object is not defined.");
    }

    // Locate the "environmentvariabledefinitions" folder
    const folderPath = "environmentvariabledefinitions/";
    const envVarFiles = Object.keys(zipContent.files).filter(
      (file) => file.startsWith(folderPath) && file.endsWith(".xml")
    );

    if (envVarFiles.length === 0) {
      console.warn(`No files found in folder: ${folderPath}`);
      return [];
    }

    const environmentVariables = [];

    for (const filePath of envVarFiles) {
      console.log(`Processing file: ${filePath}`);
      const fileContent = await zipContent.files[filePath].async("string");
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(fileContent, "text/xml");

      // Extract details for each environment variable
      const variableNode = xmlDoc.querySelector("environmentvariabledefinition");
      if (variableNode) {
        const displayName = variableNode.querySelector("displayname > label")?.getAttribute("description") || "N/A";
        const defaultValue = variableNode.querySelector("defaultvalue")?.textContent?.trim() || "N/A";

        environmentVariables.push({
          name: displayName,
          defaultValue: defaultValue,
        });
      } else {
        console.warn(`No environmentvariabledefinition node found in file: ${filePath}`);
      }
    }

    console.log("Extracted Environment Variables:", environmentVariables);
    return environmentVariables;
  } catch (error) {
    console.error("Error extracting environment variables:", error);
    return [];
  }
}

// Function to populate the environment variables in the UI
async function populateEnvironmentVariables(zipContent) {
  const envVarTable = document.getElementById("environment-variables-table");

  if (!zipContent) {
    console.error("No ZIP content available for extracting environment variables.");
    envVarTable.innerHTML = `<p style="color: red;">Please upload a ZIP file to load environment variables.</p>`;
    return;
  }

  const environmentVariables = await extractEnvironmentVariables(zipContent);

  if (environmentVariables.length === 0) {
    envVarTable.innerHTML = `<p>No environment variables found in the ZIP file.</p>`;
  } else {
    const tableHTML = `
      <table>
        <thead>
          <tr>
            <th>Display Name</th>
            <th>Default Value</th>
          </tr>
        </thead>
        <tbody>
          ${environmentVariables
            .map(
              (variable) => `
            <tr>
              <td>${escapeHTML(variable.name)}</td>
              <td>${escapeHTML(variable.defaultValue)}</td>
            </tr>
          `
            )
            .join("")}
        </tbody>
      </table>
    `;
    envVarTable.innerHTML = tableHTML;
  }
}

// Utility function to escape HTML (Prevents XSS attacks)
function escapeHTML(str) {
  const div = document.createElement("div");
  div.innerText = str;
  return div.innerHTML;
}

// Expose functions for usage
window.populateEnvironmentVariables = populateEnvironmentVariables;
